"""
Mr.X Runtime - Execution environment for Mr.X programs

The runtime provides the execution context for Mr.X programs,
including built-in functions, web API bindings, and utilities.

Author: Mr.X Team
"""

import sys
import os
from typing import Any, Dict, List, Optional, Callable, Union
from pathlib import Path
import json


class MrXError(Exception):
    """Base exception for Mr.X runtime errors"""
    def __init__(self, message: str, line: int = 0, column: int = 0):
        self.message = message
        self.line = line
        self.column = column
        super().__init__(f"Runtime Error at {line}:{column}: {message}")


class MrXValue:
    """Represents a value in Mr.X runtime"""
    def __init__(self, value: Any, value_type: str = "unknown"):
        self.value = value
        self.type = value_type

    def __str__(self):
        return str(self.value)

    def __repr__(self):
        return f"MrXValue({self.value}, {self.type})"


class Environment:
    """Execution environment for Mr.X programs"""

    def __init__(self, parent: Optional['Environment'] = None):
        self.variables: Dict[str, MrXValue] = {}
        self.functions: Dict[str, Callable] = {}
        self.classes: Dict[str, type] = {}
        self.parent = parent
        self._init_builtins()

    def _init_builtins(self):
        """Initialize built-in functions and objects"""

        # Print function
        def print_func(*args):
            output = " ".join(str(arg) for arg in args)
            print(output)
            return None

        self.functions['قول'] = print_func
        self.functions['اطبع'] = print_func

        # Input function
        def input_func(prompt: str = ""):
            return input(prompt)

        self.functions['ادخل'] = input_func

        # Type conversion functions
        self.functions['عدد'] = lambda x: MrXValue(float(x) if x else 0, "number")
        self.functions['نص'] = lambda x: MrXValue(str(x), "string")
        self.functions['منطقي'] = lambda x: MrXValue(bool(x), "boolean")

        # String functions
        self.functions['طول'] = lambda s: MrXValue(len(str(s)), "number")

        # Math functions
        self.functions['sqrt'] = lambda x: MrXValue(pow(float(x), 0.5), "number")
        self.functions['pow'] = lambda x, y: MrXValue(pow(float(x), float(y)), "number")
        self.functions['abs'] = lambda x: MrXValue(abs(float(x)), "number")
        self.functions['round'] = lambda x: MrXValue(round(float(x)), "number")

        # Array functions
        self.functions['.push'] = lambda arr, val: arr.append(val)
        self.functions['pop'] = lambda arr: arr.pop() if arr else None
        self.functions['shift'] = lambda arr: arr.pop(0) if arr else None
        self.functions['join'] = lambda arr, sep="": str(sep).join(str(x) for x in arr)
        self.functions['map'] = lambda arr, fn: [fn(x) for x in arr]
        self.functions['filter'] = lambda arr, fn: [x for x in arr if fn(x)]
        self.functions['reduce'] = lambda arr, fn, acc: None

        # JSON functions
        self.functions['json.parse'] = lambda s: json.loads(s)
        self.functions['json.stringify'] = lambda obj: json.dumps(obj)

        # File functions (Node.js environment)
        self.functions['read_file'] = lambda path: self._read_file(path)
        self.functions['write_file'] = lambda path, content: self._write_file(path, content)
        self.functions['exists'] = lambda path: os.path.exists(path)

        # HTTP functions (placeholder for browser/Node.js)
        self.functions['fetch'] = lambda url, options=None: self._fetch(url, options)

        # Time functions
        self.functions['now'] = lambda: MrXValue(__import__('time').time(), "number")
        self.functions['sleep'] = lambda seconds: __import__('time').sleep(seconds)

    def _read_file(self, path: str) -> str:
        """Read file contents"""
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return f.read()
        except Exception as e:
            raise MrXError(f"Failed to read file: {e}")

    def _write_file(self, path: str, content: str):
        """Write file contents"""
        try:
            with open(path, 'w', encoding='utf-8') as f:
                f.write(content)
        except Exception as e:
            raise MrXError(f"Failed to write file: {e}")

    def _fetch(self, url: str, options: Dict = None):
        """HTTP fetch - placeholder for actual implementation"""
        raise MrXError("fetch is only available in browser/Node.js environment")

    def get(self, name: str) -> Optional[MrXValue]:
        """Get a variable from the environment"""
        if name in self.variables:
            return self.variables[name]
        if self.parent:
            return self.parent.get(name)
        return None

    def set(self, name: str, value: Any, value_type: str = "unknown"):
        """Set a variable in the environment"""
        self.variables[name] = MrXValue(value, value_type)

    def define_function(self, name: str, func: Callable):
        """Define a function"""
        self.functions[name] = func

    def get_function(self, name: str) -> Optional[Callable]:
        """Get a function from the environment"""
        if name in self.functions:
            return self.functions[name]
        if self.parent:
            return self.parent.get_function(name)
        return None

    def define_class(self, name: str, class_def: type):
        """Define a class"""
        self.classes[name] = class_def

    def get_class(self, name: str) -> Optional[type]:
        """Get a class from the environment"""
        if name in self.classes:
            return self.classes[name]
        if self.parent:
            return self.parent.get_class(name)
        return None

    def create_child(self) -> 'Environment':
        """Create a child environment"""
        return Environment(parent=self)


class Runtime:
    """
    Mr.X Runtime - Executes Mr.X programs

    The runtime handles:
    - Program execution
    - Function calls
    - Variable management
    - Built-in function calls
    - Web API integration
    - Error handling
    """

    def __init__(self):
        self.environment = Environment()
        self.output: List[str] = []
        self.errors: List[str] = []
        self.stack_trace: List[Dict] = []

    def execute(self, ast, context: str = "console"):
        """
        Execute an AST.

        Args:
            ast: The AST to execute
            context: Execution context ("console", "web", "node")
        """
        try:
            for statement in ast.statements:
                self._execute_statement(statement)
        except MrXError as e:
            self.errors.append(str(e))
            self._print_error(e)
        except Exception as e:
            error = MrXError(str(e))
            self.errors.append(str(error))
            self._print_error(error)

    def _execute_statement(self, statement):
        """Execute a statement"""
        from ..compiler.ast_nodes import (
            PrintStatementNode, LetStatementNode, IfStatementNode,
            LoopStatementNode, FunctionStatementNode, ReturnStatementNode,
            ClassStatementNode, AssignmentStatementNode, ExpressionStatementNode
        )

        if isinstance(statement, PrintStatementNode):
            self._execute_print(statement)
        elif isinstance(statement, LetStatementNode):
            self._execute_let(statement)
        elif isinstance(statement, AssignmentStatementNode):
            self._execute_assignment(statement)
        elif isinstance(statement, IfStatementNode):
            self._execute_if(statement)
        elif isinstance(statement, LoopStatementNode):
            self._execute_loop(statement)
        elif isinstance(statement, FunctionStatementNode):
            self._execute_function(statement)
        elif isinstance(statement, ReturnStatementNode):
            return self._execute_return(statement)
        elif isinstance(statement, ClassStatementNode):
            self._execute_class(statement)
        elif isinstance(statement, ExpressionStatementNode):
            self._execute_expression(statement.expression)

    def _execute_print(self, node):
        """Execute print statement (قول)"""
        value = self._evaluate_expression(node.expression)
        output = str(value.value if isinstance(value, MrXValue) else value)
        self.output.append(output)
        print(output)

    def _execute_let(self, node):
        """Execute let statement (خلي)"""
        value = self._evaluate_expression(node.value)
        self.environment.set(node.name, value.value if isinstance(value, MrXValue) else value)

    def _execute_assignment(self, node):
        """Execute assignment statement"""
        target = self._evaluate_expression(node.target)
        value = self._evaluate_expression(node.value)

        target_name = getattr(target, 'name', str(target))
        self.environment.set(target_name, value.value if isinstance(value, MrXValue) else value)

    def _execute_if(self, node):
        """Execute if statement (لو)"""
        condition = self._evaluate_expression(node.condition)
        condition_value = condition.value if isinstance(condition, MrXValue) else condition

        if self._is_truthy(condition_value):
            for stmt in node.then_branch:
                self._execute_statement(stmt)
        elif node.else_branch:
            for stmt in node.else_branch:
                self._execute_statement(stmt)

    def _execute_loop(self, node):
        """Execute loop statement (كرر)"""
        count_expr = self._evaluate_expression(node.count)
        count = count_expr.value if isinstance(count_expr, MrXValue) else count_expr

        for i in range(int(count)):
            for stmt in node.body:
                result = self._execute_statement(stmt)
                if result is not None:  # Return statement
                    return result

    def _execute_function(self, node):
        """Execute function definition"""
        def mrx_function(*args):
            child_env = self.environment.create_child()

            # Bind parameters
            for i, param in enumerate(node.parameters):
                value = args[i] if i < len(args) else None
                child_env.set(param, value)

            # Execute body
            for stmt in node.body:
                result = self._execute_statement(stmt)
                if result is not None:
                    return result

        self.environment.define_function(node.name, mrx_function)

    def _execute_return(self, node):
        """Execute return statement (ارجع)"""
        if node.value:
            return self._evaluate_expression(node.value)
        return None

    def _execute_class(self, node):
        """Execute class definition"""
        methods = {}
        for method in node.methods:
            methods[method.name] = method

        class_dict = {
            '__name__': node.name,
            '__methods__': methods
        }

        self.environment.define_class(node.name, type(node.name, (), class_dict))

    def _execute_expression(self, expr):
        """Execute an expression"""
        return self._evaluate_expression(expr)

    def _evaluate_expression(self, expr) -> MrXValue:
        """Evaluate an expression and return a MrXValue"""
        from ..compiler.ast_nodes import (
            IdentifierNode, StringLiteralNode, NumberLiteralNode,
            BooleanLiteralNode, NullLiteralNode, ArrayLiteralNode,
            ObjectLiteralNode, BinaryExpressionNode, CallExpressionNode,
            MemberExpressionNode, IndexExpressionNode, TernaryExpressionNode
        )

        if isinstance(expr, IdentifierNode):
            value = self.environment.get(expr.name)
            return value if value else MrXValue(None, "null")

        elif isinstance(expr, StringLiteralNode):
            return MrXValue(expr.value, "string")

        elif isinstance(expr, NumberLiteralNode):
            return MrXValue(expr.value, "number")

        elif isinstance(expr, BooleanLiteralNode):
            return MrXValue(expr.value, "boolean")

        elif isinstance(expr, NullLiteralNode):
            return MrXValue(None, "null")

        elif isinstance(expr, ArrayLiteralNode):
            elements = [self._evaluate_expression(e).value for e in expr.elements]
            return MrXValue(elements, "array")

        elif isinstance(expr, ObjectLiteralNode):
            props = {k: self._evaluate_expression(v).value for k, v in expr.properties.items()}
            return MrXValue(props, "object")

        elif isinstance(expr, BinaryExpressionNode):
            return self._evaluate_binary(expr)

        elif isinstance(expr, CallExpressionNode):
            return self._evaluate_call(expr)

        elif isinstance(expr, MemberExpressionNode):
            obj = self._evaluate_expression(expr.object).value
            prop = expr.property
            if isinstance(obj, dict):
                return MrXValue(obj.get(prop), "unknown")
            return MrXValue(getattr(obj, prop, None), "unknown")

        elif isinstance(expr, IndexExpressionNode):
            obj = self._evaluate_expression(expr.object).value
            index = self._evaluate_expression(expr.index).value
            if isinstance(obj, (list, str)):
                try:
                    return MrXValue(obj[int(index)], "unknown")
                except:
                    pass
            return MrXValue(None, "null")

        elif isinstance(expr, TernaryExpressionNode):
            condition = self._evaluate_expression(expr.condition)
            if self._is_truthy(condition.value):
                return self._evaluate_expression(expr.then_expr)
            else:
                return self._evaluate_expression(expr.else_expr)

        return MrXValue(None, "null")

    def _evaluate_binary(self, expr) -> MrXValue:
        """Evaluate a binary expression"""
        left = self._evaluate_expression(expr.left)
        right = self._evaluate_expression(expr.right)

        left_val = left.value if isinstance(left, MrXValue) else left
        right_val = right.value if isinstance(right, MrXValue) else right

        result = None
        result_type = "number"

        try:
            if expr.operator in ['+', '-', '*', '/', '%']:
                left_num = float(left_val) if left_val is not None else 0
                right_num = float(right_val) if right_val is not None else 0

                if expr.operator == '+':
                    result = left_num + right_num
                elif expr.operator == '-':
                    result = left_num - right_num
                elif expr.operator == '*':
                    result = left_num * right_num
                elif expr.operator == '/':
                    result = left_num / right_num if right_num != 0 else 0
                elif expr.operator == '%':
                    result = left_num % right_num

            elif expr.operator in ['==', '!=', '<', '>', '<=', '>=']:
                result_type = "boolean"
                if expr.operator == '==':
                    result = left_val == right_val
                elif expr.operator == '!=':
                    result = left_val != right_val
                elif expr.operator == '<':
                    result = float(left_val or 0) < float(right_val or 0)
                elif expr.operator == '>':
                    result = float(left_val or 0) > float(right_val or 0)
                elif expr.operator == '<=':
                    result = float(left_val or 0) <= float(right_val or 0)
                elif expr.operator == '>=':
                    result = float(left_val or 0) >= float(right_val or 0)

            elif expr.operator in ['&&', '||']:
                result_type = "boolean"
                if expr.operator == '&&':
                    result = self._is_truthy(left_val) and self._is_truthy(right_val)
                elif expr.operator == '||':
                    result = self._is_truthy(left_val) or self._is_truthy(right_val)

        except Exception as e:
            result = None

        return MrXValue(result, result_type)

    def _evaluate_call(self, expr) -> MrXValue:
        """Evaluate a function call"""
        callee = self._evaluate_expression(expr.callee)

        # Get the function
        func = None
        if isinstance(callee, MrXValue) and callable(callee.value):
            func = callee.value
        elif isinstance(expr.callee, IdentifierNode):
            func = self.environment.get_function(expr.callee.name)

        if not func:
            return MrXValue(None, "null")

        # Evaluate arguments
        args = [self._evaluate_expression(arg).value for arg in expr.arguments]

        try:
            result = func(*args)
            return MrXValue(result, "unknown")
        except Exception as e:
            self.errors.append(str(e))
            return MrXValue(None, "null")

    def _is_truthy(self, value) -> bool:
        """Check if a value is truthy"""
        if value is None:
            return False
        if isinstance(value, bool):
            return value
        if isinstance(value, (int, float)):
            return value != 0
        if isinstance(value, str):
            return len(value) > 0
        if isinstance(value, (list, dict)):
            return len(value) > 0
        return True

    def _print_error(self, error: MrXError):
        """Print an error message"""
        print(f"Error: {error.message}", file=sys.stderr)

    def get_output(self) -> List[str]:
        """Get all output"""
        return self.output

    def get_errors(self) -> List[str]:
        """Get all errors"""
        return self.errors


def create_runtime() -> Runtime:
    """Create a new runtime instance"""
    return Runtime()


def execute(ast, context: str = "console") -> Runtime:
    """
    Execute an AST and return the runtime.

    Args:
        ast: The AST to execute
        context: Execution context

    Returns:
        The runtime with execution results
    """
    runtime = create_runtime()
    runtime.execute(ast, context)
    return runtime


if __name__ == "__main__":
    # Test runtime
    from ..compiler.parser import parse

    test_code = '''
خلي x = 10
قول x

خلي name = "Mohsen"
قول "مرحبا " + name

لو x > 5:
    قول "x is greater than 5"

كرر 3:
    قول "iteration"
'''

    ast = parse(test_code)
    runtime = execute(ast)
    print("\nOutput:", runtime.get_output())
    print("Errors:", runtime.get_errors())