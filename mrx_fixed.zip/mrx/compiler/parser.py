"""
Mr.X Parser - Parses Mr.X source code into AST

A simpler, working implementation of the Mr.X parser.
Uses a simplified grammar approach.

Author: Mr.X Team
"""

from typing import List, Optional, Any, Dict
from pathlib import Path

from .lexer import tokenize, Token, TokenType
from .ast_nodes import (
    ProgramNode, Position,
    PrintStatementNode, LetStatementNode, AssignmentStatementNode,
    IfStatementNode, LoopStatementNode,
    FunctionStatementNode, ReturnStatementNode, ClassStatementNode,
    ImportStatementNode, ExpressionStatementNode,
    IdentifierNode, StringLiteralNode, NumberLiteralNode, BooleanLiteralNode,
    NullLiteralNode, ArrayLiteralNode, ObjectLiteralNode,
    BinaryExpressionNode, UnaryExpressionNode, CallExpressionNode,
    MemberExpressionNode, IndexExpressionNode, TernaryExpressionNode,
    PageNode, TitleNode, TextNode, ButtonNode, ImageNode, InputNode,
    NavNode, CardNode, SectionNode, FormNode, FooterNode, ContainerNode,
    GridNode, FlexNode, LinkNode, VideoNode, WebElementNode
)


class ParserError(Exception):
    """Exception raised when parser encounters an error"""
    def __init__(self, message: str, line: int = 0, column: int = 0, filename: str = "main"):
        self.message = message
        self.line = line
        self.column = column
        self.filename = filename
        super().__init__(f"Parser Error in {filename} at {line}:{column}: {message}")


class Parser:
    """
    Mr.X Parser - Converts source code into AST.

    Uses a simple recursive descent parser for basic Mr.X constructs.
    """

    def __init__(self, filename: str = "main"):
        self.filename = filename
        self.tokens: List[Token] = []
        self.pos = 0

    def parse(self, source: str) -> ProgramNode:
        """Parse source code and return AST"""
        self.tokens = tokenize(source, self.filename)
        self.pos = 0
        return self.parse_statements()

    def parse_file(self, filepath: str) -> ProgramNode:
        """Parse a source file"""
        with open(filepath, 'r', encoding='utf-8') as f:
            source = f.read()
        return self.parse(source)

    def current_token(self) -> Optional[Token]:
        """Get current token"""
        if self.pos < len(self.tokens):
            return self.tokens[self.pos]
        return None

    def peek_token(self, offset: int = 1) -> Optional[Token]:
        """Peek at a future token"""
        if self.pos + offset < len(self.tokens):
            return self.tokens[self.pos + offset]
        return None

    def advance(self) -> Optional[Token]:
        """Advance to next token"""
        token = self.current_token()
        self.pos += 1
        return token

    def expect(self, token_type: TokenType) -> Token:
        """Expect a specific token type"""
        token = self.current_token()
        if token is None or token.type != token_type:
            raise ParserError(
                f"Expected {token_type}, got {token.type if token else 'EOF'}",
                line=token.line if token else 0,
                column=token.column if token else 0
            )
        return self.advance()

    def parse_statements(self) -> ProgramNode:
        """Parse all statements"""
        program = ProgramNode()
        program.statements = []

        while self.current_token() and self.current_token().type != TokenType.EOF:
            try:
                stmt = self.parse_statement()
                if stmt:
                    program.statements.append(stmt)
            except Exception as e:
                # Skip problematic statements
                if self.current_token() and self.current_token().type != TokenType.EOF:
                    self.advance()  # Skip problematic token
                continue

        return program

    def parse_statement(self):
        """Parse a single statement"""
        token = self.current_token()
        if token is None:
            return None

        # Handle newlines
        if token.type == TokenType.NEWLINE:
            self.advance()
            return self.parse_statement()

        # Print statement
        if token.type == TokenType.PRINT:
            return self.parse_print()

        # Let statement
        if token.type == TokenType.LET:
            return self.parse_let()

        # If statement
        if token.type == TokenType.IF:
            return self.parse_if()

        # Loop statement
        if token.type == TokenType.LOOP:
            return self.parse_loop()

        # Function statement
        if token.type == TokenType.FUNCTION:
            return self.parse_function()

        # Return statement
        if token.type == TokenType.RETURN:
            return self.parse_return()

        # Import statement
        if token.type == TokenType.IMPORT:
            return self.parse_import()

        # Web elements
        if token.type == TokenType.PAGE:
            return self.parse_page()

        if token.type == TokenType.TITLE:
            return self.parse_title()

        if token.type == TokenType.TEXT:
            return self.parse_text()

        if token.type == TokenType.BUTTON:
            return self.parse_button()

        if token.type == TokenType.IMAGE:
            return self.parse_image()

        if token.type == TokenType.INPUT:
            return self.parse_input()

        if token.type == TokenType.CARD:
            return self.parse_card()

        if token.type == TokenType.SECTION:
            return self.parse_section()

        if token.type == TokenType.FORM:
            return self.parse_form()

        if token.type == TokenType.FOOTER:
            return self.parse_footer()

        if token.type == TokenType.NAV:
            return self.parse_nav()

        if token.type == TokenType.CONTAINER:
            return self.parse_container()

        if token.type == TokenType.GRID:
            return self.parse_grid()

        if token.type == TokenType.FLEX:
            return self.parse_flex()

        if token.type == TokenType.LINK:
            return self.parse_link()

        # Expression statement
        expr = self.parse_expression()
        if expr:
            return ExpressionStatementNode(expression=expr)

        return None

    def parse_print(self):
        """Parse print statement (قول)"""
        self.advance()  # Skip 'قول'
        expr = self.parse_expression()
        return PrintStatementNode(expression=expr or StringLiteralNode(value=""))

    def parse_let(self):
        """Parse let statement (خلي)"""
        self.advance()  # Skip 'خلي'

        name = ""
        if self.current_token() and self.current_token().type == TokenType.IDENTIFIER:
            name = self.advance().value

        if self.current_token() and self.current_token().type == TokenType.ASSIGN:
            self.advance()

        value = self.parse_expression()
        return LetStatementNode(name=name, value=value or StringLiteralNode(value=""))

    def parse_if(self):
        """Parse if statement (لو)"""
        self.advance()  # Skip 'لو'
        condition = self.parse_expression()

        # Skip colon
        if self.current_token() and self.current_token().type == TokenType.COLON:
            self.advance()

        # Parse then branch
        then_branch = []
        while self.current_token() and self.current_token().type != TokenType.EOF:
            if self.current_token().type == TokenType.NEWLINE:
                self.advance()
                break
            stmt = self.parse_statement()
            if stmt:
                then_branch.append(stmt)

        # Check for else
        else_branch = None
        if self.current_token() and self.current_token().type == TokenType.ELSE:
            self.advance()
            if self.current_token() and self.current_token().type == TokenType.COLON:
                self.advance()
            else_branch = []
            while self.current_token() and self.current_token().type != TokenType.EOF:
                if self.current_token().type == TokenType.NEWLINE:
                    self.advance()
                    break
                stmt = self.parse_statement()
                if stmt:
                    else_branch.append(stmt)

        return IfStatementNode(condition=condition, then_branch=then_branch, else_branch=else_branch)

    def parse_loop(self):
        """Parse loop statement (كرر)"""
        self.advance()  # Skip 'كرر'
        count = self.parse_expression()

        # Skip colon
        if self.current_token() and self.current_token().type == TokenType.COLON:
            self.advance()

        # Parse body
        body = []
        while self.current_token() and self.current_token().type != TokenType.EOF:
            if self.current_token().type == TokenType.NEWLINE:
                self.advance()
                break
            stmt = self.parse_statement()
            if stmt:
                body.append(stmt)

        return LoopStatementNode(count=count, body=body)

    def parse_function(self):
        """Parse function statement (دالة)"""
        self.advance()  # Skip 'دالة'

        name = ""
        if self.current_token() and self.current_token().type == TokenType.IDENTIFIER:
            name = self.advance().value

        # Skip parentheses
        if self.current_token() and self.current_token().type == TokenType.LPAREN:
            self.advance()
            if self.current_token() and self.current_token().type == TokenType.RPAREN:
                self.advance()

        # Skip colon
        if self.current_token() and self.current_token().type == TokenType.COLON:
            self.advance()

        # Parse body
        body = []
        while self.current_token() and self.current_token().type != TokenType.EOF:
            if self.current_token().type == TokenType.NEWLINE:
                self.advance()
                break
            stmt = self.parse_statement()
            if stmt:
                body.append(stmt)

        return FunctionStatementNode(name=name, parameters=[], body=body)

    def parse_return(self):
        """Parse return statement (ارجع)"""
        self.advance()  # Skip 'ارجع'
        value = self.parse_expression()
        return ReturnStatementNode(value=value)

    def parse_import(self):
        """Parse import statement (استورد)"""
        self.advance()  # Skip 'استورد'
        module = ""
        if self.current_token() and self.current_token().type == TokenType.STRING:
            module = self.advance().value
        return ImportStatementNode(module=module)

    def parse_expression(self):
        """Parse an expression"""
        token = self.current_token()
        if token is None:
            return None

        # String literal
        if token.type == TokenType.STRING:
            self.advance()
            return StringLiteralNode(value=token.value)

        # Number literal
        if token.type == TokenType.NUMBER:
            self.advance()
            return NumberLiteralNode(value=float(token.value))

        # Boolean
        if token.type in [TokenType.TRUE, TokenType.EN_TRUE]:
            self.advance()
            return BooleanLiteralNode(value=True)

        if token.type in [TokenType.FALSE, TokenType.EN_FALSE]:
            self.advance()
            return BooleanLiteralNode(value=False)

        # Null
        if token.type == TokenType.EN_NULL:
            self.advance()
            return NullLiteralNode()

        # Identifier
        if token.type == TokenType.IDENTIFIER:
            name = self.advance().value

            # Check for assignment
            if self.current_token() and self.current_token().type == TokenType.ASSIGN:
                self.advance()
                value = self.parse_expression()
                return BinaryExpressionNode(
                    left=IdentifierNode(name=name),
                    operator="=",
                    right=value
                )

            # Check for binary operators
            if self.current_token() and self.current_token().type in [
                TokenType.PLUS, TokenType.MINUS, TokenType.MULTIPLY, TokenType.DIVIDE,
                TokenType.EQUAL, TokenType.NOT_EQUAL, TokenType.LESS, TokenType.GREATER,
                TokenType.LESS_EQUAL, TokenType.GREATER_EQUAL
            ]:
                op = self.advance().value
                right = self.parse_expression()
                return BinaryExpressionNode(
                    left=IdentifierNode(name=name),
                    operator=op,
                    right=right
                )

            return IdentifierNode(name=name)

        # Parentheses
        if token.type == TokenType.LPAREN:
            self.advance()
            expr = self.parse_expression()
            if self.current_token() and self.current_token().type == TokenType.RPAREN:
                self.advance()
            return expr

        return None

    # Web element parsers
    def parse_page(self):
        """Parse page element (صفحة)"""
        self.advance()  # Skip 'صفحة'
        title = ""
        if self.current_token() and self.current_token().type == TokenType.STRING:
            title = self.advance().value

        # Skip colon
        if self.current_token() and self.current_token().type == TokenType.COLON:
            self.advance()

        children = []
        while self.current_token() and self.current_token().type != TokenType.EOF:
            if self.current_token().type == TokenType.NEWLINE:
                self.advance()
                break
            stmt = self.parse_statement()
            if stmt:
                children.append(stmt)

        return PageNode(name=title, children=children, title=title)

    def parse_title(self):
        """Parse title element (عنوان)"""
        self.advance()  # Skip 'عنوان'
        text = ""
        if self.current_token() and self.current_token().type == TokenType.STRING:
            text = self.advance().value
        return TitleNode(name=text)

    def parse_text(self):
        """Parse text element (نص)"""
        self.advance()  # Skip 'نص'
        text = ""
        if self.current_token() and self.current_token().type == TokenType.STRING:
            text = self.advance().value
        return TextNode(name=text)

    def parse_button(self):
        """Parse button element (زر)"""
        self.advance()  # Skip 'زر'
        text = ""
        if self.current_token() and self.current_token().type == TokenType.STRING:
            text = self.advance().value
        return ButtonNode(name=text, text=text)

    def parse_image(self):
        """Parse image element (صورة)"""
        self.advance()  # Skip 'صورة'
        src = ""
        if self.current_token() and self.current_token().type == TokenType.STRING:
            src = self.advance().value
        return ImageNode(name=src, src=src)

    def parse_input(self):
        """Parse input element (حقل)"""
        self.advance()  # Skip 'حقل'
        label = ""
        if self.current_token() and self.current_token().type == TokenType.STRING:
            label = self.advance().value
        return InputNode(name=label, label=label)

    def parse_card(self):
        """Parse card element (بطاقة)"""
        self.advance()  # Skip 'بطاقة'

        # Skip colon
        if self.current_token() and self.current_token().type == TokenType.COLON:
            self.advance()

        children = []
        while self.current_token() and self.current_token().type != TokenType.EOF:
            if self.current_token().type == TokenType.NEWLINE:
                self.advance()
                break
            stmt = self.parse_statement()
            if stmt:
                children.append(stmt)

        return CardNode(name="card", children=children)

    def parse_section(self):
        """Parse section element (قسم)"""
        self.advance()  # Skip 'قسم'

        if self.current_token() and self.current_token().type == TokenType.COLON:
            self.advance()

        children = []
        while self.current_token() and self.current_token().type != TokenType.EOF:
            if self.current_token().type == TokenType.NEWLINE:
                self.advance()
                break
            stmt = self.parse_statement()
            if stmt:
                children.append(stmt)

        return SectionNode(name="section", children=children)

    def parse_form(self):
        """Parse form element (نموذج)"""
        self.advance()  # Skip 'نموذج'

        if self.current_token() and self.current_token().type == TokenType.COLON:
            self.advance()

        children = []
        while self.current_token() and self.current_token().type != TokenType.EOF:
            if self.current_token().type == TokenType.NEWLINE:
                self.advance()
                break
            stmt = self.parse_statement()
            if stmt:
                children.append(stmt)

        return FormNode(name="form", children=children)

    def parse_footer(self):
        """Parse footer element (تذييل)"""
        self.advance()  # Skip 'تذييل'

        if self.current_token() and self.current_token().type == TokenType.COLON:
            self.advance()

        children = []
        while self.current_token() and self.current_token().type != TokenType.EOF:
            if self.current_token().type == TokenType.NEWLINE:
                self.advance()
                break
            stmt = self.parse_statement()
            if stmt:
                children.append(stmt)

        return FooterNode(name="footer", children=children)

    def parse_nav(self):
        """Parse nav element (قائمة)"""
        self.advance()  # Skip 'قائمة'

        if self.current_token() and self.current_token().type == TokenType.COLON:
            self.advance()

        children = []
        while self.current_token() and self.current_token().type != TokenType.EOF:
            if self.current_token().type == TokenType.NEWLINE:
                self.advance()
                break
            stmt = self.parse_statement()
            if stmt:
                children.append(stmt)

        return NavNode(name="nav", children=children)

    def parse_container(self):
        """Parse container element (حاوية)"""
        self.advance()  # Skip 'حاوية'

        if self.current_token() and self.current_token().type == TokenType.COLON:
            self.advance()

        children = []
        while self.current_token() and self.current_token().type != TokenType.EOF:
            if self.current_token().type == TokenType.NEWLINE:
                self.advance()
                break
            stmt = self.parse_statement()
            if stmt:
                children.append(stmt)

        return ContainerNode(name="container", children=children)

    def parse_grid(self):
        """Parse grid element (شبكة)"""
        self.advance()  # Skip 'شبكة'
        columns = 3
        if self.current_token() and self.current_token().type == TokenType.NUMBER:
            columns = int(self.advance().value)

        if self.current_token() and self.current_token().type == TokenType.COLON:
            self.advance()

        children = []
        while self.current_token() and self.current_token().type != TokenType.EOF:
            if self.current_token().type == TokenType.NEWLINE:
                self.advance()
                break
            stmt = self.parse_statement()
            if stmt:
                children.append(stmt)

        return GridNode(name="grid", columns=columns, children=children)

    def parse_flex(self):
        """Parse flex element (مرن)"""
        self.advance()  # Skip 'مرن'

        if self.current_token() and self.current_token().type == TokenType.COLON:
            self.advance()

        children = []
        while self.current_token() and self.current_token().type != TokenType.EOF:
            if self.current_token().type == TokenType.NEWLINE:
                self.advance()
                break
            stmt = self.parse_statement()
            if stmt:
                children.append(stmt)

        return FlexNode(name="flex", children=children)

    def parse_link(self):
        """Parse link element (رابط)"""
        self.advance()  # Skip 'رابط'
        href = ""
        text = ""
        if self.current_token() and self.current_token().type == TokenType.STRING:
            href = self.advance().value
        if self.current_token() and self.current_token().type == TokenType.STRING:
            text = self.advance().value
        return LinkNode(name=text, href=href, text=text)


def parse(source: str, filename: str = "main") -> ProgramNode:
    """Parse source code"""
    parser = Parser(filename)
    return parser.parse(source)


def parse_file(filepath: str) -> ProgramNode:
    """Parse a source file"""
    parser = Parser(filepath)
    return parser.parse_file(filepath)


if __name__ == "__main__":
    # Test parser
    test_code = '''
قول "مرحبا"
خلي name = "أحمد"
لو name == "أحمد":
    قول "مرحبا يا أحمد"
كرر 3:
    قول "iteration"
'''
    ast = parse(test_code)
    print(f"Parsed {len(ast.statements)} statements")
    for stmt in ast.statements:
        print(f"  - {type(stmt).__name__}")