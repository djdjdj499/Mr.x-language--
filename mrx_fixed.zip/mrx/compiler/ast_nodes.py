"""
Mr.X AST Nodes - Abstract Syntax Tree Node Definitions

This module defines all AST node classes used to represent Mr.X programs.
Each node type represents a different construct in the language.

Author: Mr.X Team
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Optional, Any, Dict
from enum import Enum


class NodeType(Enum):
    """Enumeration of all AST node types"""
    # Program structure
    PROGRAM = "Program"
    SOURCE_FILE = "SourceFile"

    # Statements
    EXPRESSION_STATEMENT = "ExpressionStatement"
    PRINT_STATEMENT = "PrintStatement"
    LET_STATEMENT = "LetStatement"
    ASSIGNMENT_STATEMENT = "AssignmentStatement"
    IF_STATEMENT = "IfStatement"
    LOOP_STATEMENT = "LoopStatement"
    FOR_LOOP_STATEMENT = "ForLoopStatement"
    WHILE_LOOP_STATEMENT = "WhileLoopStatement"
    FUNCTION_STATEMENT = "FunctionStatement"
    RETURN_STATEMENT = "ReturnStatement"
    CLASS_STATEMENT = "ClassStatement"
    IMPORT_STATEMENT = "ImportStatement"
    AWAIT_STATEMENT = "AwaitStatement"

    # Expressions
    IDENTIFIER = "Identifier"
    STRING_LITERAL = "StringLiteral"
    NUMBER_LITERAL = "NumberLiteral"
    BOOLEAN_LITERAL = "BooleanLiteral"
    NULL_LITERAL = "NullLiteral"
    ARRAY_LITERAL = "ArrayLiteral"
    OBJECT_LITERAL = "ObjectLiteral"
    BINARY_EXPRESSION = "BinaryExpression"
    UNARY_EXPRESSION = "UnaryExpression"
    CALL_EXPRESSION = "CallExpression"
    MEMBER_EXPRESSION = "MemberExpression"
    INDEX_EXPRESSION = "IndexExpression"
    TERNARY_EXPRESSION = "TernaryExpression"
    ARROW_FUNCTION = "ArrowFunction"

    # Web elements
    PAGE = "Page"
    TITLE = "Title"
    TEXT = "Text"
    BUTTON = "Button"
    IMAGE = "Image"
    INPUT = "Input"
    COLOR = "Color"
    NAV = "Nav"
    CARD = "Card"
    SECTION = "Section"
    FORM = "Form"
    FOOTER = "Footer"
    LINK = "Link"
    CONTAINER = "Container"
    GRID = "Grid"
    FLEX = "Flex"
    VIDEO = "Video"


@dataclass
class Position:
    """Source code position information"""
    line: int = 0
    column: int = 0
    start: int = 0
    end: int = 0
    filename: str = "main"


@dataclass
class BaseNode(ABC):
    """Abstract base class for all AST nodes"""
    node_type: NodeType = NodeType.PROGRAM
    position: Optional[Position] = None

    @abstractmethod
    def accept(self, visitor: 'ASTVisitor'):
        """Accept a visitor for the visitor pattern"""
        pass


@dataclass
class ProgramNode(BaseNode):
    """Root node of the AST representing a complete program"""
    statements: List['BaseNode'] = field(default_factory=list)
    imports: List['ImportStatementNode'] = field(default_factory=list)
    metadata: Dict[str, Any] = field(default_factory=dict)

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_program(self)


@dataclass
class SourceFileNode(BaseNode):
    """Represents a single source file"""
    filename: str = "main"
    program: ProgramNode = field(default_factory=ProgramNode)
    is_entry: bool = False

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_source_file(self)


# Statement Nodes

@dataclass
class ExpressionStatementNode(BaseNode):
    """A statement that evaluates an expression"""
    expression: 'ExpressionNode' = None

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_expression_statement(self)


@dataclass
class PrintStatementNode(BaseNode):
    """قول statement - prints values to output"""
    expression: 'ExpressionNode' = None
    newline: bool = True

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_print_statement(self)


@dataclass
class LetStatementNode(BaseNode):
    """خلي statement - declares a variable"""
    name: str = ""
    value: 'ExpressionNode' = None
    is_constant: bool = False
    var_type: Optional[str] = None

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_let_statement(self)


@dataclass
class AssignmentStatementNode(BaseNode):
    """Assignment statement"""
    target: 'ExpressionNode' = None
    value: 'ExpressionNode' = None
    operator: str = "="

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_assignment_statement(self)


@dataclass
class IfStatementNode(BaseNode):
    """لو statement - conditional execution"""
    condition: 'ExpressionNode' = None
    then_branch: List[BaseNode] = field(default_factory=list)
    else_branch: Optional[List[BaseNode]] = None

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_if_statement(self)


@dataclass
class LoopStatementNode(BaseNode):
    """كرر statement - loops a fixed number of times"""
    count: 'ExpressionNode' = None
    body: List[BaseNode] = field(default_factory=list)
    variable: Optional[str] = None

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_loop_statement(self)


@dataclass
class WhileLoopStatementNode(BaseNode):
    """While loop statement"""
    condition: 'ExpressionNode' = None
    body: List[BaseNode] = field(default_factory=list)

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_while_loop_statement(self)


@dataclass
class FunctionStatementNode(BaseNode):
    """دالة statement - defines a function"""
    name: str = ""
    parameters: List[str] = field(default_factory=list)
    body: List[BaseNode] = field(default_factory=list)
    return_type: Optional[str] = None
    is_async: bool = False
    is_arrow: bool = False

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_function_statement(self)


@dataclass
class ReturnStatementNode(BaseNode):
    """ارجع statement - returns a value from function"""
    value: Optional['ExpressionNode'] = None

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_return_statement(self)


@dataclass
class ClassStatementNode(BaseNode):
    """صنف statement - defines a class"""
    name: str = ""
    base_classes: List[str] = field(default_factory=list)
    properties: List['LetStatementNode'] = field(default_factory=list)
    methods: List['FunctionStatementNode'] = field(default_factory=list)
    constructor: Optional['FunctionStatementNode'] = None

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_class_statement(self)


@dataclass
class ImportStatementNode(BaseNode):
    """استورد statement - imports a module"""
    module: str = ""
    items: List[str] = field(default_factory=list)
    alias: Optional[str] = None
    is_relative: bool = False

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_import_statement(self)


@dataclass
class AwaitStatementNode(BaseNode):
    """Await statement for async operations"""
    expression: 'ExpressionNode' = None

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_await_statement(self)


# Expression Nodes

@dataclass
class IdentifierNode(BaseNode):
    """Identifier (variable name)"""
    name: str = ""

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_identifier(self)


@dataclass
class StringLiteralNode(BaseNode):
    """String literal value"""
    value: str = ""
    is_raw: bool = False

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_string_literal(self)


@dataclass
class NumberLiteralNode(BaseNode):
    """Number literal value (integer or float)"""
    value: float = 0.0
    is_integer: bool = True

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_number_literal(self)


@dataclass
class BooleanLiteralNode(BaseNode):
    """Boolean literal value"""
    value: bool = False

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_boolean_literal(self)


@dataclass
class NullLiteralNode(BaseNode):
    """Null literal value"""

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_null_literal(self)


@dataclass
class ArrayLiteralNode(BaseNode):
    """Array literal value"""
    elements: List['ExpressionNode'] = field(default_factory=list)

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_array_literal(self)


@dataclass
class ObjectLiteralNode(BaseNode):
    """Object literal value"""
    properties: Dict[str, 'ExpressionNode'] = field(default_factory=dict)

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_object_literal(self)


@dataclass
class BinaryExpressionNode(BaseNode):
    """Binary expression (e.g., a + b, x == y)"""
    left: 'ExpressionNode' = None
    operator: str = "+"
    right: 'ExpressionNode' = None

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_binary_expression(self)


@dataclass
class UnaryExpressionNode(BaseNode):
    """Unary expression (e.g., -x, !y)"""
    operator: str = ""
    operand: 'ExpressionNode' = None

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_unary_expression(self)


@dataclass
class CallExpressionNode(BaseNode):
    """Function call expression"""
    callee: 'ExpressionNode' = None
    arguments: List['ExpressionNode'] = field(default_factory=list)

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_call_expression(self)


@dataclass
class MemberExpressionNode(BaseNode):
    """Member access expression (e.g., obj.property)"""
    object: 'ExpressionNode' = None
    property: str = ""
    is_computed: bool = False

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_member_expression(self)


@dataclass
class IndexExpressionNode(BaseNode):
    """Index access expression (e.g., arr[0])"""
    object: 'ExpressionNode' = None
    index: 'ExpressionNode' = None

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_index_expression(self)


@dataclass
class TernaryExpressionNode(BaseNode):
    """Ternary expression (e.g., a ? b : c)"""
    condition: 'ExpressionNode' = None
    then_expr: 'ExpressionNode' = None
    else_expr: 'ExpressionNode' = None

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_ternary_expression(self)


@dataclass
class ArrowFunctionNode(BaseNode):
    """Arrow function expression"""
    parameters: List[str] = field(default_factory=list)
    body: BaseNode = None
    is_async: bool = False

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_arrow_function(self)


# Web Element Nodes

@dataclass
class WebElementNode(BaseNode):
    """Base class for web framework elements"""
    name: str = ""
    attributes: Dict[str, 'ExpressionNode'] = field(default_factory=dict)
    children: List[BaseNode] = field(default_factory=list)
    classes: List[str] = field(default_factory=list)
    element_id: Optional[str] = None


@dataclass
class PageNode(WebElementNode):
    """صفحة - defines a web page"""
    title: str = ""
    dark_mode: bool = False
    language: str = "ar"

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_page(self)


@dataclass
class TitleNode(WebElementNode):
    """عنوان - defines a heading/title"""
    level: int = 1

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_title(self)


@dataclass
class TextNode(WebElementNode):
    """نص - defines text content"""

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_text(self)


@dataclass
class ButtonNode(WebElementNode):
    """زر - defines a button"""
    text: str = ""
    on_click: Optional[str] = None

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_button(self)


@dataclass
class ImageNode(WebElementNode):
    """صورة - defines an image"""
    src: str = ""
    alt: str = ""

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_image(self)


@dataclass
class InputNode(WebElementNode):
    """حقل - defines an input field"""
    input_type: str = "text"
    placeholder: str = ""
    label: str = ""

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_input(self)


@dataclass
class NavNode(WebElementNode):
    """قائمة - defines a navigation bar"""

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_nav(self)


@dataclass
class CardNode(WebElementNode):
    """بطاقة - defines a card component"""

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_card(self)


@dataclass
class SectionNode(WebElementNode):
    """قسم - defines a section"""

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_section(self)


@dataclass
class FormNode(WebElementNode):
    """نموذج - defines a form"""
    action: str = ""
    method: str = "POST"

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_form(self)


@dataclass
class FooterNode(WebElementNode):
    """تذييل - defines a footer"""

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_footer(self)


@dataclass
class ContainerNode(WebElementNode):
    """حاوية - defines a container"""

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_container(self)


@dataclass
class GridNode(WebElementNode):
    """شبكة - defines a grid layout"""
    columns: int = 3

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_grid(self)


@dataclass
class FlexNode(WebElementNode):
    """مرن - defines a flexbox layout"""
    direction: str = "row"
    align: str = "center"
    justify: str = "center"

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_flex(self)


@dataclass
class LinkNode(WebElementNode):
    """رابط - defines a hyperlink"""
    href: str = ""
    text: str = ""

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_link(self)


@dataclass
class VideoNode(WebElementNode):
    """فيديو - defines a video element"""
    src: str = ""
    autoplay: bool = False
    controls: bool = True

    def accept(self, visitor: 'ASTVisitor'):
        return visitor.visit_video(self)


# Type aliases for better readability
ExpressionNode = BaseNode
StatementNode = BaseNode


# AST Visitor Interface

class ASTVisitor(ABC):
    """Visitor interface for traversing AST nodes"""

    # Program structure
    @abstractmethod
    def visit_program(self, node: ProgramNode):
        pass

    @abstractmethod
    def visit_source_file(self, node):
        pass

    # Statements
    @abstractmethod
    def visit_expression_statement(self, node: ExpressionStatementNode):
        pass

    @abstractmethod
    def visit_print_statement(self, node: PrintStatementNode):
        pass

    @abstractmethod
    def visit_let_statement(self, node: LetStatementNode):
        pass

    @abstractmethod
    def visit_assignment_statement(self, node: AssignmentStatementNode):
        pass

    @abstractmethod
    def visit_if_statement(self, node: IfStatementNode):
        pass

    @abstractmethod
    def visit_loop_statement(self, node: LoopStatementNode):
        pass

    @abstractmethod
    def visit_while_loop_statement(self, node: WhileLoopStatementNode):
        pass

    @abstractmethod
    def visit_function_statement(self, node: FunctionStatementNode):
        pass

    @abstractmethod
    def visit_return_statement(self, node: ReturnStatementNode):
        pass

    @abstractmethod
    def visit_class_statement(self, node: ClassStatementNode):
        pass

    @abstractmethod
    def visit_import_statement(self, node: ImportStatementNode):
        pass

    @abstractmethod
    def visit_await_statement(self, node: AwaitStatementNode):
        pass

    # Expressions
    @abstractmethod
    def visit_identifier(self, node: IdentifierNode):
        pass

    @abstractmethod
    def visit_string_literal(self, node: StringLiteralNode):
        pass

    @abstractmethod
    def visit_number_literal(self, node: NumberLiteralNode):
        pass

    @abstractmethod
    def visit_boolean_literal(self, node: BooleanLiteralNode):
        pass

    @abstractmethod
    def visit_null_literal(self, node: NullLiteralNode):
        pass

    @abstractmethod
    def visit_array_literal(self, node: ArrayLiteralNode):
        pass

    @abstractmethod
    def visit_object_literal(self, node: ObjectLiteralNode):
        pass

    @abstractmethod
    def visit_binary_expression(self, node: BinaryExpressionNode):
        pass

    @abstractmethod
    def visit_unary_expression(self, node: UnaryExpressionNode):
        pass

    @abstractmethod
    def visit_call_expression(self, node: CallExpressionNode):
        pass

    @abstractmethod
    def visit_member_expression(self, node: MemberExpressionNode):
        pass

    @abstractmethod
    def visit_index_expression(self, node: IndexExpressionNode):
        pass

    @abstractmethod
    def visit_ternary_expression(self, node: TernaryExpressionNode):
        pass

    @abstractmethod
    def visit_arrow_function(self, node: ArrowFunctionNode):
        pass

    # Web elements
    @abstractmethod
    def visit_page(self, node: PageNode):
        pass

    @abstractmethod
    def visit_title(self, node: TitleNode):
        pass

    @abstractmethod
    def visit_text(self, node: TextNode):
        pass

    @abstractmethod
    def visit_button(self, node: ButtonNode):
        pass

    @abstractmethod
    def visit_image(self, node: ImageNode):
        pass

    @abstractmethod
    def visit_input(self, node: InputNode):
        pass

    @abstractmethod
    def visit_nav(self, node: NavNode):
        pass

    @abstractmethod
    def visit_card(self, node: CardNode):
        pass

    @abstractmethod
    def visit_section(self, node: SectionNode):
        pass

    @abstractmethod
    def visit_form(self, node: FormNode):
        pass

    @abstractmethod
    def visit_footer(self, node: FooterNode):
        pass

    @abstractmethod
    def visit_container(self, node: ContainerNode):
        pass

    @abstractmethod
    def visit_grid(self, node: GridNode):
        pass

    @abstractmethod
    def visit_flex(self, node: FlexNode):
        pass

    @abstractmethod
    def visit_link(self, node: LinkNode):
        pass

    @abstractmethod
    def visit_video(self, node: VideoNode):
        pass