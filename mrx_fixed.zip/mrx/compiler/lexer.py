"""
Mr.X Lexer - Tokenizer for Arabic-first Programming Language

The lexer is responsible for breaking source code into tokens.
It supports Arabic keywords and English identifiers.

Token Types:
- Keywords (Arabic): قول, خلي, لو, غير_ذلك, كرر, دالة, ارجع, استورد, صنف, صفحة, عنوان, نص, زر, صورة, حقل, لون
- Keywords (English): if, else, for, while, function, return, class, etc.
- Identifiers: variable names (English), function names
- Literals: strings, numbers, booleans
- Operators: +, -, *, /, ==, !=, <, >, <=, >=, =
- Delimiters: :, (), {}, []
- Special: comments, whitespace, newlines
"""

from enum import Enum, auto
from dataclasses import dataclass
from typing import Optional, List


class TokenType(Enum):
    """All token types supported by Mr.X"""
    # Keywords (Arabic)
    PRINT = auto()           # قول
    LET = auto()             # خلي
    IF = auto()              # لو
    ELSE = auto()            # غير_ذلك
    LOOP = auto()            # كرر
    FUNCTION = auto()        # دالة
    RETURN = auto()          # ارجع
    IMPORT = auto()          # استورد
    CLASS = auto()           # صنف
    PAGE = auto()            # صفحة
    TITLE = auto()           # عنوان
    TEXT = auto()            # نص
    BUTTON = auto()          # زر
    IMAGE = auto()           # صورة
    INPUT = auto()           # حقل
    COLOR = auto()           # لون
    TRUE = auto()            # صحيح
    FALSE = auto()            # خطأ
    AND = auto()             # و
    OR = auto()              # أو
    NOT = auto()             # ليس

    # Web framework elements
    NAV = auto()             # قائمة
    CARD = auto()            # بطاقة
    SECTION = auto()         # قسم
    FORM = auto()            # نموذج
    FOOTER = auto()          # تذييل
    LINK = auto()            # رابط
    CONTAINER = auto()       # حاوية
    GRID = auto()            # شبكة
    FLEX = auto()            # مرن
    CENTER = auto()          # مركز
    SPACE = auto()            # فضاء
    DARK = auto()            # ليلي
    LIGHT = auto()           # نهاري

    # English keywords
    EN_TRUE = auto()         # true
    EN_FALSE = auto()        # false
    EN_IF = auto()          # if
    EN_ELSE = auto()        # else
    EN_FOR = auto()         # for
    EN_WHILE = auto()       # while
    EN_FUNCTION = auto()    # function
    EN_RETURN = auto()       # return
    EN_CLASS = auto()        # class
    EN_NEW = auto()          # new
    EN_VAR = auto()          # var
    EN_CONST = auto()        # const
    EN_NULL = auto()         # null
    EN_UNDEFINED = auto()     # undefined
    EN_AWAIT = auto()        # await
    EN_ASYNC = auto()        # async
    EN_TRY = auto()          # try
    EN_CATCH = auto()        # catch
    EN_THROW = auto()        # throw

    # Operators
    PLUS = auto()            # +
    MINUS = auto()           # -
    MULTIPLY = auto()        # *
    DIVIDE = auto()          # /
    MODULO = auto()          # %
    ASSIGN = auto()          # =
    EQUAL = auto()           # ==
    NOT_EQUAL = auto()       # !=
    LESS = auto()            # <
    GREATER = auto()         # >
    LESS_EQUAL = auto()      # <=
    GREATER_EQUAL = auto()   # >=
    AND_OP = auto()          # &&
    OR_OP = auto()           # ||
    NOT_OP = auto()          # !
    PLUS_EQUAL = auto()      # +=
    MINUS_EQUAL = auto()     # -=
    MULTIPLY_EQUAL = auto()  # *=
    DIVIDE_EQUAL = auto()    # /=

    # Delimiters
    LPAREN = auto()          # (
    RPAREN = auto()          # )
    LBRACE = auto()          # {
    RBRACE = auto()           # }
    LBRACKET = auto()        # [
    RBRACKET = auto()         # ]
    COMMA = auto()           # ,
    DOT = auto()             # .
    COLON = auto()           # :
    SEMICOLON = auto()       # ;
    ARROW = auto()           # ->
    DOUBLE_COLON = auto()    # ::
    QUESTION = auto()        # ?

    # Literals
    STRING = auto()          # "string" or 'string'
    NUMBER = auto()          # 123, 45.67
    IDENTIFIER = auto()      # variable names
    ARABIC_TEXT = auto()     # نص "العربية"

    # Special tokens
    NEWLINE = auto()         # newline
    INDENT = auto()          # indentation
    DEDENT = auto()          # dedentation
    EOF = auto()             # end of file
    COMMENT = auto()         # # comment
    BLOCK_COMMENT = auto()    # ### block comment ###

    # Error token
    ERROR = auto()


@dataclass
class Token:
    """Represents a single token in the source code"""
    type: TokenType
    value: str
    line: int
    column: int
    position: int  # Absolute position in source

    def __repr__(self):
        return f"Token({self.type.name}, '{self.value}', {self.line}:{self.column})"


class ArabicKeywords:
    """Maps Arabic keywords to their token types"""

    KEYWORDS = {
        # Core language keywords
        "قول": TokenType.PRINT,
        "خلي": TokenType.LET,
        "لو": TokenType.IF,
        "غير_ذلك": TokenType.ELSE,
        "كرر": TokenType.LOOP,
        "دالة": TokenType.FUNCTION,
        "ارجع": TokenType.RETURN,
        "استورد": TokenType.IMPORT,
        "صنف": TokenType.CLASS,
        "صحيح": TokenType.TRUE,
        "خطأ": TokenType.FALSE,
        "و": TokenType.AND,
        "أو": TokenType.OR,
        "ليس": TokenType.NOT,

        # Web framework keywords
        "صفحة": TokenType.PAGE,
        "عنوان": TokenType.TITLE,
        "نص": TokenType.TEXT,
        "زر": TokenType.BUTTON,
        "صورة": TokenType.IMAGE,
        "حقل": TokenType.INPUT,
        "لون": TokenType.COLOR,
        "قائمة": TokenType.NAV,
        "بطاقة": TokenType.CARD,
        "قسم": TokenType.SECTION,
        "نموذج": TokenType.FORM,
        "تذييل": TokenType.FOOTER,
        "رابط": TokenType.LINK,
        "حاوية": TokenType.CONTAINER,
        "شبكة": TokenType.GRID,
        "مرن": TokenType.FLEX,
        "مركز": TokenType.CENTER,
        "فضاء": TokenType.SPACE,
        "ليلي": TokenType.DARK,
        "نهاري": TokenType.LIGHT,

        # English keywords (lowercase)
        "true": TokenType.EN_TRUE,
        "false": TokenType.EN_FALSE,
        "if": TokenType.EN_IF,
        "else": TokenType.EN_ELSE,
        "for": TokenType.EN_FOR,
        "while": TokenType.EN_WHILE,
        "function": TokenType.EN_FUNCTION,
        "return": TokenType.EN_RETURN,
        "class": TokenType.EN_CLASS,
        "new": TokenType.EN_NEW,
        "var": TokenType.EN_VAR,
        "const": TokenType.EN_CONST,
        "null": TokenType.EN_NULL,
        "undefined": TokenType.EN_UNDEFINED,
        "await": TokenType.EN_AWAIT,
        "async": TokenType.EN_ASYNC,
        "try": TokenType.EN_TRY,
        "catch": TokenType.EN_CATCH,
        "throw": TokenType.EN_THROW,
        "true": TokenType.EN_TRUE,
        "false": TokenType.EN_FALSE,
    }

    @classmethod
    def lookup(cls, text: str) -> Optional[TokenType]:
        """Look up a keyword in the dictionary"""
        return cls.KEYWORDS.get(text)


class LexerError(Exception):
    """Exception raised when lexer encounters an error"""
    def __init__(self, message: str, line: int, column: int, position: int):
        self.message = message
        self.line = line
        self.column = column
        self.position = position
        super().__init__(f"Lexer Error at {line}:{column}: {message}")


class Lexer:
    """
    Mr.X Lexer - Tokenizes Arabic-first source code.

    The lexer processes the source code character by character and
    produces a stream of tokens for the parser.

    Supported features:
    - Arabic keywords
    - English identifiers and keywords
    - String literals (single and double quotes)
    - Number literals (integers and floats)
    - Operators and delimiters
    - Comments (single-line and multi-line)
    - Indentation tracking for Python-like syntax
    """

    def __init__(self, source: str, filename: str = "main"):
        """
        Initialize the lexer with source code.

        Args:
            source: The source code to tokenize
            filename: Name of the source file (for error reporting)
        """
        self.source = source
        self.filename = filename
        self.pos = 0
        self.line = 1
        self.column = 1
        self.start_pos = 0
        self.start_line = 1
        self.start_column = 1
        self.tokens: List[Token] = []
        self.current_char = self.source[0] if self.source else None

    def advance(self):
        """Move to the next character"""
        self.pos += 1
        if self.pos < len(self.source):
            if self.current_char == '\n':
                self.line += 1
                self.column = 1
            else:
                self.column += 1
            self.current_char = self.source[self.pos]
        else:
            self.current_char = None

    def peek(self, offset: int = 1) -> Optional[str]:
        """Look at a character ahead without consuming it"""
        peek_pos = self.pos + offset
        if peek_pos < len(self.source):
            return self.source[peek_pos]
        return None

    def skip_whitespace(self):
        """Skip whitespace characters (except newlines)"""
        while self.current_char is not None and self.current_char in ' \t\r':
            self.advance()

    def skip_line_comment(self):
        """Skip single-line comments (# ...)"""
        while self.current_char is not None and self.current_char != '\n':
            self.advance()

    def skip_block_comment(self):
        """Skip multi-line comments (### ... ###)"""
        while self.current_char is not None:
            if self.current_char == '#' and self.peek() == '#' and self.peek(2) == '#':
                # End of block comment
                self.advance()  # Skip first #
                self.advance()  # Skip second #
                self.advance()  # Skip third #
                return
            self.advance()

    def read_string(self, quote_char: str) -> str:
        """Read a string literal"""
        self.advance()  # Skip opening quote
        result = []

        while self.current_char is not None and self.current_char != quote_char:
            if self.current_char == '\\':
                self.advance()
                if self.current_char == 'n':
                    result.append('\n')
                elif self.current_char == 't':
                    result.append('\t')
                elif self.current_char == '\\':
                    result.append('\\')
                elif self.current_char == quote_char:
                    result.append(quote_char)
                else:
                    result.append(self.current_char)
            elif self.current_char == '\n':
                raise LexerError("Unterminated string literal", self.line, self.column, self.pos)
            else:
                result.append(self.current_char)
            self.advance()

        if self.current_char is None:
            raise LexerError("Unterminated string literal", self.start_line, self.start_column, self.start_pos)

        self.advance()  # Skip closing quote
        return ''.join(result)

    def read_number(self) -> str:
        """Read a number literal (integer or float)"""
        result = []
        has_dot = False

        while self.current_char is not None and (self.current_char.isdigit() or self.current_char == '.'):
            if self.current_char == '.':
                if has_dot:
                    raise LexerError("Invalid number format", self.line, self.column, self.pos)
                has_dot = True
            result.append(self.current_char)
            self.advance()

        return ''.join(result)

    def read_identifier(self) -> str:
        """Read an identifier (English letters, numbers, underscores)"""
        result = []

        # First character must be a letter or underscore
        while self.current_char is not None and (self.current_char.isalnum() or self.current_char in '_'):
            result.append(self.current_char)
            self.advance()

        return ''.join(result)

    def read_arabic_text(self) -> str:
        """Read Arabic text content (for string literals in Arabic context)"""
        result = []

        # Arabic text can contain letters, numbers, spaces, and some punctuation
        while self.current_char is not None and (
            '\u0600' <= self.current_char <= '\u06FF' or  # Arabic
            '\u0750' <= self.current_char <= '\u077F' or  # Arabic Supplement
            self.current_char.isalnum() or
            self.current_char in ' _-.()[]{}:،؛؟!؟' or  # Common punctuation
            self.current_char == ' '
        ):
            result.append(self.current_char)
            self.advance()

        return ''.join(result).strip()

    def make_token(self, token_type: TokenType, value: str = None):
        """Create a new token and add it to the token list"""
        if value is None:
            value = self.source[self.start_pos:self.pos]
        token = Token(token_type, value, self.start_line, self.start_column, self.start_pos)
        self.tokens.append(token)
        return token

    def tokenize(self) -> List[Token]:
        """
        Main tokenization method.
        Converts source code into a list of tokens.

        Returns:
            List of tokens representing the source code
        """
        while self.current_char is not None:
            self.start_pos = self.pos
            self.start_line = self.line
            self.start_column = self.column

            # Newline
            if self.current_char == '\n':
                self.make_token(TokenType.NEWLINE)
                self.advance()
                continue

            # Skip whitespace (but track it for indentation)
            if self.current_char in ' \t':
                self.advance()
                continue

            # Line comment
            if self.current_char == '#':
                if self.peek() == '#' and self.peek(2) == '#':
                    self.skip_block_comment()
                else:
                    self.skip_line_comment()
                continue

            # String literals
            if self.current_char in '"\'':
                string_value = self.read_string(self.current_char)
                self.make_token(TokenType.STRING, string_value)
                continue

            # Numbers
            if self.current_char.isdigit():
                number_str = self.read_number()
                self.make_token(TokenType.NUMBER, number_str)
                continue

            # Identifiers and keywords (English)
            if self.current_char.isalpha() or self.current_char == '_':
                identifier = self.read_identifier()

                # Check if it's an Arabic keyword
                if identifier in ArabicKeywords.KEYWORDS:
                    self.make_token(ArabicKeywords.lookup(identifier), identifier)
                else:
                    self.make_token(TokenType.IDENTIFIER, identifier)
                continue

            # Arabic text (direct text content for web elements)
            if '\u0600' <= self.current_char <= '\u06FF':
                arabic_text = self.read_arabic_text()
                self.make_token(TokenType.ARABIC_TEXT, arabic_text)
                continue

            # Operators and delimiters
            char = self.current_char

            if char == '+':
                self.advance()
                if self.current_char == '=':
                    self.advance()
                    self.make_token(TokenType.PLUS_EQUAL, '+=')
                else:
                    self.make_token(TokenType.PLUS, '+')
                continue

            if char == '-':
                self.advance()
                if self.current_char == '=':
                    self.advance()
                    self.make_token(TokenType.MINUS_EQUAL, '-=')
                elif self.current_char == '>':
                    self.advance()
                    self.make_token(TokenType.ARROW, '->')
                else:
                    self.make_token(TokenType.MINUS, '-')
                continue

            if char == '*':
                self.advance()
                if self.current_char == '=':
                    self.advance()
                    self.make_token(TokenType.MULTIPLY_EQUAL, '*=')
                else:
                    self.make_token(TokenType.MULTIPLY, '*')
                continue

            if char == '/':
                self.advance()
                if self.current_char == '=':
                    self.advance()
                    self.make_token(TokenType.DIVIDE_EQUAL, '/=')
                else:
                    self.make_token(TokenType.DIVIDE, '/')
                continue

            if char == '%':
                self.make_token(TokenType.MODULO)
                self.advance()
                continue

            if char == '=':
                self.advance()
                if self.current_char == '=':
                    self.advance()
                    self.make_token(TokenType.EQUAL)
                else:
                    self.make_token(TokenType.ASSIGN)
                continue

            if char == '!':
                self.advance()
                if self.current_char == '=':
                    self.advance()
                    self.make_token(TokenType.NOT_EQUAL)
                else:
                    self.make_token(TokenType.NOT_OP)
                continue

            if char == '<':
                self.advance()
                if self.current_char == '=':
                    self.advance()
                    self.make_token(TokenType.LESS_EQUAL)
                else:
                    self.make_token(TokenType.LESS)
                continue

            if char == '>':
                self.advance()
                if self.current_char == '=':
                    self.advance()
                    self.make_token(TokenType.GREATER_EQUAL)
                else:
                    self.make_token(TokenType.GREATER)
                continue

            if char == '&':
                self.advance()
                if self.current_char == '&':
                    self.advance()
                    self.make_token(TokenType.AND_OP)
                else:
                    raise LexerError("Expected '&&' for logical AND", self.line, self.column, self.pos)
                continue

            if char == '|':
                self.advance()
                if self.current_char == '|':
                    self.advance()
                    self.make_token(TokenType.OR_OP)
                else:
                    raise LexerError("Expected '||' for logical OR", self.line, self.column, self.pos)
                continue

            if char == '(':
                self.make_token(TokenType.LPAREN)
                self.advance()
                continue

            if char == ')':
                self.make_token(TokenType.RPAREN)
                self.advance()
                continue

            if char == '{':
                self.make_token(TokenType.LBRACE)
                self.advance()
                continue

            if char == '}':
                self.make_token(TokenType.RBRACE)
                self.advance()
                continue

            if char == '[':
                self.make_token(TokenType.LBRACKET)
                self.advance()
                continue

            if char == ']':
                self.make_token(TokenType.RBRACKET)
                self.advance()
                continue

            if char == ',':
                self.make_token(TokenType.COMMA)
                self.advance()
                continue

            if char == '.':
                self.make_token(TokenType.DOT)
                self.advance()
                continue

            if char == ':':
                self.make_token(TokenType.COLON)
                self.advance()
                continue

            if char == ';':
                self.make_token(TokenType.SEMICOLON)
                self.advance()
                continue

            if char == '?':
                self.make_token(TokenType.QUESTION)
                self.advance()
                continue

            # Unknown character
            raise LexerError(f"Unknown character '{self.current_char}'", self.line, self.column, self.pos)

        # Add EOF token
        self.make_token(TokenType.EOF, '')
        return self.tokens


def tokenize(source: str, filename: str = "main") -> List[Token]:
    """
    Convenience function to tokenize source code.

    Args:
        source: Source code to tokenize
        filename: Source filename for error reporting

    Returns:
        List of tokens
    """
    lexer = Lexer(source, filename)
    return lexer.tokenize()


if __name__ == "__main__":
    # Test the lexer
    test_code = '''
خلي name = "Mohsen"
قول "hello world"

لو name == "Mohsen":
    قول "owner"

كرر 5:
    قول "hello"
'''
    tokens = tokenize(test_code)
    for token in tokens:
        print(token)