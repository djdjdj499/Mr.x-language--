"""
Mr.X Semantic Analyzer - Performs semantic analysis on AST

The semantic analyzer performs type checking, scope analysis,
and validates the program structure before code generation.

Author: Mr.X Team
"""

from typing import Dict, List, Optional, Set, Any
from dataclasses import dataclass, field
from enum import Enum

from .ast_nodes import (
    ProgramNode, BaseNode, NodeType,
    FunctionStatementNode, ClassStatementNode, LetStatementNode,
    IdentifierNode, ReturnStatementNode, IfStatementNode,
    LoopStatementNode, ImportStatementNode, CallExpressionNode,
    MemberExpressionNode, BinaryExpressionNode, UnaryExpressionNode,
    ExpressionNode, AssignmentStatementNode, PrintStatementNode,
    ExpressionStatementNode, WhileLoopStatementNode, FunctionStatementNode
)


class SymbolType(Enum):
    """Types of symbols in the symbol table"""
    VARIABLE = "variable"
    CONSTANT = "constant"
    FUNCTION = "function"
    CLASS = "class"
    PARAMETER = "parameter"
    PROPERTY = "property"
    MODULE = "module"


@dataclass
class Symbol:
    """Represents a symbol in the symbol table"""
    name: str
    symbol_type: SymbolType
    data_type: Optional[str] = None
    value: Any = None
    is_global: bool = False
    is_mutable: bool = True
    defined_in: Optional[str] = None
    references: List[int] = field(default_factory=list)


@dataclass
class FunctionInfo:
    """Information about a function"""
    name: str
    parameters: List[str]
    return_type: Optional[str] = None
    is_async: bool = False
    is_generator: bool = False
    calls: List[str] = field(default_factory=list)


@dataclass
class ClassInfo:
    """Information about a class"""
    name: str
    base_classes: List[str] = field(default_factory=list)
    properties: List[str] = field(default_factory=list)
    methods: List[str] = field(default_factory=list)
    constructor_params: List[str] = field(default_factory=list)


@dataclass
class Scope:
    """Represents a lexical scope"""
    name: str
    parent: Optional['Scope'] = None
    symbols: Dict[str, Symbol] = field(default_factory=dict)
    depth: int = 0
    is_function_scope: bool = False
    is_class_scope: bool = False


class ScopeManager:
    """Manages scopes for variable resolution"""

    def __init__(self):
        self.scopes: List[Scope] = []
        self._init_global_scope()

    def _init_global_scope(self):
        """Initialize the global scope"""
        global_scope = Scope(name="global", depth=0)
        self.scopes.append(global_scope)

        # Add built-in functions and types
        self._add_builtin_symbols(global_scope)

    def _add_builtin_symbols(self, scope: Scope):
        """Add built-in symbols to a scope"""
        # Built-in functions
        builtins = [
            ("قول", SymbolType.FUNCTION, "null"),
            ("اطبع", SymbolType.FUNCTION, "null"),
            ("استورد", SymbolType.FUNCTION, "module"),
            ("دالة", SymbolType.FUNCTION, "function"),
            ("صنف", SymbolType.FUNCTION, "class"),
            ("console", SymbolType.VARIABLE, "object"),
            ("document", SymbolType.VARIABLE, "object"),
            ("fetch", SymbolType.FUNCTION, "Promise"),
            ("JSON", SymbolType.VARIABLE, "object"),
            ("Math", SymbolType.VARIABLE, "object"),
        ]

        for name, sym_type, data_type in builtins:
            scope.symbols[name] = Symbol(
                name=name,
                symbol_type=sym_type,
                data_type=data_type,
                is_global=True
            )

    def push_scope(self, name: str, is_function: bool = False, is_class: bool = False) -> Scope:
        """Push a new scope onto the stack"""
        parent = self.current_scope()
        new_scope = Scope(
            name=name,
            parent=parent,
            depth=parent.depth + 1,
            is_function_scope=is_function,
            is_class_scope=is_class
        )
        self.scopes.append(new_scope)
        return new_scope

    def pop_scope(self) -> Optional[Scope]:
        """Pop the current scope"""
        if len(self.scopes) > 1:
            return self.scopes.pop()
        return None

    def current_scope(self) -> Scope:
        """Get the current scope"""
        return self.scopes[-1] if self.scopes else None

    def lookup(self, name: str) -> Optional[Symbol]:
        """Look up a symbol in all accessible scopes"""
        scope = self.current_scope()
        while scope:
            if name in scope.symbols:
                return scope.symbols[name]
            scope = scope.parent
        return None

    def define(self, symbol: Symbol) -> bool:
        """Define a symbol in the current scope"""
        current = self.current_scope()
        if current:
            # Check for redefinition
            if name in current.symbols:
                return False
            current.symbols[symbol.name] = symbol
            return True
        return False

    def is_defined(self, name: str) -> bool:
        """Check if a name is defined in any accessible scope"""
        return self.lookup(name) is not None


class SemanticError(Exception):
    """Exception raised during semantic analysis"""
    def __init__(self, message: str, node: BaseNode = None, line: int = 0, column: int = 0):
        self.message = message
        self.node = node
        self.line = line
        self.column = column
        super().__init__(f"Semantic Error at {line}:{column}: {message}")


class TypeSystem:
    """Type system for Mr.X language"""

    # Primitive types
    PRIMITIVE_TYPES = {
        "عدد": "number",
        "نص": "string",
        "منطقي": "boolean",
        "فارغ": "null",
        "undefined": "undefined",
        "object": "object",
        "function": "function",
    }

    # Type compatibility matrix
    TYPE_COMPATIBILITY = {
        "number": {"number", "string", "any"},
        "string": {"string", "any"},
        "boolean": {"boolean", "any"},
        "null": {"null", "undefined", "any"},
        "undefined": {"undefined", "any"},
        "object": {"object", "any"},
        "function": {"function", "any"},
        "any": {"*"},
    }

    @classmethod
    def is_compatible(cls, from_type: str, to_type: str) -> bool:
        """Check if one type is compatible with another"""
        if to_type == "any":
            return True
        if from_type == to_type:
            return True
        compatible = cls.TYPE_COMPATIBILITY.get(from_type, set())
        return to_type in compatible or "*" in compatible

    @classmethod
    def get_type(cls, node: BaseNode) -> str:
        """Get the type of an AST node"""
        from .ast_nodes import (
            NumberLiteralNode, StringLiteralNode, BooleanLiteralNode,
            NullLiteralNode, ArrayLiteralNode, ObjectLiteralNode,
            IdentifierNode, BinaryExpressionNode, CallExpressionNode,
            MemberExpressionNode
        )

        if isinstance(node, NumberLiteralNode):
            return "number"
        elif isinstance(node, StringLiteralNode):
            return "string"
        elif isinstance(node, BooleanLiteralNode):
            return "boolean"
        elif isinstance(node, (NullLiteralNode,)):
            return "null"
        elif isinstance(node, ArrayLiteralNode):
            return "array"
        elif isinstance(node, ObjectLiteralNode):
            return "object"
        elif isinstance(node, IdentifierNode):
            return "unknown"
        elif isinstance(node, BinaryExpressionNode):
            return cls._get_binary_result_type(node.operator)
        elif isinstance(node, CallExpressionNode):
            return "unknown"
        elif isinstance(node, MemberExpressionNode):
            return "unknown"
        else:
            return "unknown"

    @classmethod
    def _get_binary_result_type(cls, operator: str) -> str:
        """Get the result type of a binary operation"""
        numeric_ops = {"+", "-", "*", "/", "%"}
        comparison_ops = {"==", "!=", "<", ">", "<=", ">="}
        logical_ops = {"&&", "||", "!"}

        if operator in numeric_ops:
            return "number"
        elif operator in comparison_ops:
            return "boolean"
        elif operator in logical_ops:
            return "boolean"
        else:
            return "unknown"


class SemanticAnalyzer:
    """
    Performs semantic analysis on Mr.X programs.

    The semantic analyzer:
    1. Builds and manages symbol tables
    2. Performs type checking
    3. Validates program structure
    4. Detects undefined variables
    5. Checks function calls
    6. Validates class hierarchies
    """

    def __init__(self, filename: str = "main"):
        self.filename = filename
        self.scope_manager = ScopeManager()
        self.errors: List[SemanticError] = []
        self.warnings: List[str] = []
        self.function_info: Dict[str, FunctionInfo] = {}
        self.class_info: Dict[str, ClassInfo] = {}
        self.current_function: Optional[str] = None
        self.current_class: Optional[str] = None
        self.analyzed_nodes: Set[int] = set()

    def analyze(self, ast: ProgramNode) -> ProgramNode:
        """
        Perform semantic analysis on an AST.

        Args:
            ast: The AST to analyze

        Returns:
            The analyzed AST (possibly modified)
        """
        try:
            self._visit_program(ast)
        except SemanticError as e:
            self.errors.append(e)

        if self.errors:
            raise self.errors[0]

        return ast

    def _visit_program(self, node: ProgramNode):
        """Visit the program node"""
        for statement in node.statements:
            self._visit_statement(statement)

    def _visit_statement(self, node: BaseNode):
        """Visit a statement node"""
        node_id = id(node)
        if node_id in self.analyzed_nodes:
            return

        from .ast_nodes import (
            LetStatementNode, PrintStatementNode, IfStatementNode,
            LoopStatementNode, FunctionStatementNode, ReturnStatementNode,
            ClassStatementNode, ImportStatementNode, ExpressionStatementNode,
            AssignmentStatementNode
        )

        if isinstance(node, LetStatementNode):
            self._visit_let_statement(node)
        elif isinstance(node, PrintStatementNode):
            self._visit_expression(node.expression)
        elif isinstance(node, IfStatementNode):
            self._visit_if_statement(node)
        elif isinstance(node, LoopStatementNode):
            self._visit_loop_statement(node)
        elif isinstance(node, FunctionStatementNode):
            self._visit_function_statement(node)
        elif isinstance(node, ReturnStatementNode):
            self._visit_return_statement(node)
        elif isinstance(node, ClassStatementNode):
            self._visit_class_statement(node)
        elif isinstance(node, ImportStatementNode):
            self._visit_import_statement(node)
        elif isinstance(node, ExpressionStatementNode):
            self._visit_expression(node.expression)
        elif isinstance(node, AssignmentStatementNode):
            self._visit_assignment_statement(node)

        self.analyzed_nodes.add(id(node))

    def _visit_let_statement(self, node: LetStatementNode):
        """Visit a let statement (variable declaration)"""
        # Check for redefinition
        if self.scope_manager.is_defined(node.name):
            self.errors.append(SemanticError(
                f"Variable '{node.name}' is already defined",
                node, 0, 0
            ))
            return

        # Visit the value expression
        if node.value:
            self._visit_expression(node.value)

        # Define the variable
        symbol = Symbol(
            name=node.name,
            symbol_type=SymbolType.CONSTANT if node.is_constant else SymbolType.VARIABLE,
            data_type=node.var_type,
            is_mutable=not node.is_constant,
            defined_in=self.current_function or "global"
        )

        self.scope_manager.define(symbol)

    def _visit_if_statement(self, node: IfStatementNode):
        """Visit an if statement"""
        # Check condition type
        self._visit_expression(node.condition)

        # Visit then branch
        self.scope_manager.push_scope("if")
        for stmt in node.then_branch:
            self._visit_statement(stmt)
        self.scope_manager.pop_scope()

        # Visit else branch
        if node.else_branch:
            self.scope_manager.push_scope("else")
            for stmt in node.else_branch:
                self._visit_statement(stmt)
            self.scope_manager.pop_scope()

    def _visit_loop_statement(self, node: LoopStatementNode):
        """Visit a loop statement"""
        # Check count type
        self._visit_expression(node.count)

        # Push loop scope
        self.scope_manager.push_scope("loop")

        # Create loop variable if specified
        if node.variable:
            symbol = Symbol(
                name=node.variable,
                symbol_type=SymbolType.VARIABLE,
                data_type="number",
                is_mutable=True,
                defined_in=self.current_function or "loop"
            )
            self.scope_manager.define(symbol)

        # Visit body
        for stmt in node.body:
            self._visit_statement(stmt)

        self.scope_manager.pop_scope()

    def _visit_function_statement(self, node: FunctionStatementNode):
        """Visit a function statement"""
        # Check for redefinition
        if self.scope_manager.is_defined(node.name):
            self.errors.append(SemanticError(
                f"Function '{node.name}' is already defined",
                node, 0, 0
            ))

        # Store function info
        self.function_info[node.name] = FunctionInfo(
            name=node.name,
            parameters=node.parameters,
            return_type=node.return_type,
            is_async=node.is_async
        )

        # Create function scope
        old_function = self.current_function
        self.current_function = node.name

        self.scope_manager.push_scope(node.name, is_function=True)

        # Define parameters
        for param in node.parameters:
            symbol = Symbol(
                name=param,
                symbol_type=SymbolType.PARAMETER,
                data_type="unknown",
                is_mutable=True,
                defined_in=node.name
            )
            self.scope_manager.define(symbol)

        # Visit body
        for stmt in node.body:
            self._visit_statement(stmt)

        self.scope_manager.pop_scope()
        self.current_function = old_function

        # Define the function symbol
        symbol = Symbol(
            name=node.name,
            symbol_type=SymbolType.FUNCTION,
            data_type="function",
            is_global=self.scope_manager.current_scope().depth == 0
        )
        self.scope_manager.define(symbol)

    def _visit_return_statement(self, node: ReturnStatementNode):
        """Visit a return statement"""
        if not self.current_function:
            self.warnings.append(f"Return statement outside function at line {node.position.line}")

        if node.value:
            self._visit_expression(node.value)

    def _visit_class_statement(self, node: ClassStatementNode):
        """Visit a class statement"""
        # Check for redefinition
        if self.scope_manager.is_defined(node.name):
            self.errors.append(SemanticError(
                f"Class '{node.name}' is already defined",
                node, 0, 0
            ))

        # Store class info
        self.class_info[node.name] = ClassInfo(
            name=node.name,
            base_classes=node.base_classes,
            methods=[m.name for m in node.methods] if node.methods else []
        )

        # Create class scope
        old_class = self.current_class
        self.current_class = node.name

        self.scope_manager.push_scope(node.name, is_class=True)

        # Define properties
        for prop in node.properties:
            symbol = Symbol(
                name=prop.name,
                symbol_type=SymbolType.PROPERTY,
                data_type=prop.var_type,
                is_mutable=not prop.is_constant,
                defined_in=node.name
            )
            self.scope_manager.define(symbol)

        # Visit methods
        for method in node.methods:
            self._visit_function_statement(method)

        self.scope_manager.pop_scope()
        self.current_class = old_class

        # Define the class symbol
        symbol = Symbol(
            name=node.name,
            symbol_type=SymbolType.CLASS,
            data_type="class",
            is_global=self.scope_manager.current_scope().depth == 0
        )
        self.scope_manager.define(symbol)

    def _visit_import_statement(self, node: ImportStatementNode):
        """Visit an import statement"""
        # Validate import path
        if not node.module:
            self.errors.append(SemanticError(
                "Import statement requires a module path",
                node, 0, 0
            ))

        # Define module symbol
        name = node.alias or node.module.split('/')[-1]
        symbol = Symbol(
            name=name,
            symbol_type=SymbolType.MODULE,
            data_type="module"
        )
        self.scope_manager.define(symbol)

    def _visit_assignment_statement(self, node: AssignmentStatementNode):
        """Visit an assignment statement"""
        # Visit target
        self._visit_expression(node.target)

        # Visit value
        self._visit_expression(node.value)

    def _visit_expression(self, node: BaseNode):
        """Visit an expression node"""
        from .ast_nodes import (
            IdentifierNode, StringLiteralNode, NumberLiteralNode,
            BooleanLiteralNode, BinaryExpressionNode, UnaryExpressionNode,
            CallExpressionNode, MemberExpressionNode, ArrayLiteralNode,
            ObjectLiteralNode, TernaryExpressionNode
        )

        if isinstance(node, IdentifierNode):
            self._visit_identifier(node)
        elif isinstance(node, (StringLiteralNode, NumberLiteralNode,
                                BooleanLiteralNode)):
            pass  # Literals don't need analysis
        elif isinstance(node, BinaryExpressionNode):
            self._visit_binary_expression(node)
        elif isinstance(node, UnaryExpressionNode):
            self._visit_unary_expression(node)
        elif isinstance(node, CallExpressionNode):
            self._visit_call_expression(node)
        elif isinstance(node, MemberExpressionNode):
            self._visit_member_expression(node)
        elif isinstance(node, ArrayLiteralNode):
            for elem in node.elements:
                self._visit_expression(elem)
        elif isinstance(node, ObjectLiteralNode):
            for val in node.properties.values():
                self._visit_expression(val)

    def _visit_identifier(self, node: IdentifierNode):
        """Visit an identifier"""
        if not self.scope_manager.is_defined(node.name):
            # Check if it's a built-in or web element
            builtins = {"قول", "اطبع", "استورد", "دالة", "صنف", "لو", "غير_ذلك",
                       "كرر", "ارجع", "صحيح", "خطأ", "صفحة", "عنوان", "نص",
                       "زر", "صورة", "حقل", "لون", "قائمة", "بطاقة", "قسم",
                       "نموذج", "تذييل", "رابط", "حاوية", "شبكة", "مرن", "فضاء",
                       "مركز", "ليلي", "نهاري"}
            if node.name not in builtins:
                self.warnings.append(
                    f"Undefined variable '{node.name}' at line {node.position.line}"
                )

    def _visit_binary_expression(self, node: BinaryExpressionNode):
        """Visit a binary expression"""
        self._visit_expression(node.left)
        self._visit_expression(node.right)

    def _visit_unary_expression(self, node: UnaryExpressionNode):
        """Visit a unary expression"""
        self._visit_expression(node.operand)

    def _visit_call_expression(self, node: CallExpressionNode):
        """Visit a call expression"""
        self._visit_expression(node.callee)

        for arg in node.arguments:
            self._visit_expression(arg)

    def _visit_member_expression(self, node: MemberExpressionNode):
        """Visit a member expression"""
        self._visit_expression(node.object)

    def get_errors(self) -> List[SemanticError]:
        """Get all semantic errors"""
        return self.errors

    def get_warnings(self) -> List[str]:
        """Get all semantic warnings"""
        return self.warnings

    def has_errors(self) -> bool:
        """Check if there are any errors"""
        return len(self.errors) > 0


def analyze(ast: ProgramNode, filename: str = "main") -> ProgramNode:
    """
    Perform semantic analysis on an AST.

    Args:
        ast: The AST to analyze
        filename: Source filename for error reporting

    Returns:
        The analyzed AST

    Raises:
        SemanticError if analysis fails
    """
    analyzer = SemanticAnalyzer(filename)
    return analyzer.analyze(ast)


if __name__ == "__main__":
    # Test semantic analysis
    from .parser import parse

    test_code = '''
خلي x = 10
خلي y = "hello"

دالة greet(name):
    قول "مرحبا" + name
    ارجع name

لو x > 5:
    قول "x is greater than 5"
'''

    ast = parse(test_code)
    analyzer = SemanticAnalyzer()

    try:
        analyzer.analyze(ast)
        print("Semantic analysis passed!")
        print(f"Warnings: {analyzer.get_warnings()}")
    except SemanticError as e:
        print(f"Semantic error: {e}")