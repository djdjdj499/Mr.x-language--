"""
Mr.X Programming Language - Compiler Module

This module provides the complete compiler infrastructure for Mr.X,
including lexer, parser, AST, semantic analyzer, and code generators.

Author: Mr.X Team
Version: 1.0.0

Usage:
    from compiler import parse, analyze
    from compiler.codegen import generate_html, generate_css, generate_js

    # Parse source code
    ast = parse(source_code)

    # Analyze
    ast = analyze(ast)

    # Generate output
    html = generate_html(ast)
    css = generate_css(ast)
    js = generate_js(ast)
"""

from .lexer import Lexer, Token, TokenType, tokenize, LexerError
from .parser import Parser, parse, parse_file, ParserError
from .semantic import SemanticAnalyzer, analyze, SemanticError
from .ast_nodes import (
    ProgramNode, BaseNode, NodeType, Position,
    PrintStatementNode, LetStatementNode, IfStatementNode,
    LoopStatementNode, FunctionStatementNode, ReturnStatementNode,
    ClassStatementNode, ImportStatementNode, AssignmentStatementNode,
    IdentifierNode, StringLiteralNode, NumberLiteralNode, BooleanLiteralNode,
    BinaryExpressionNode, CallExpressionNode, MemberExpressionNode,
    PageNode, TitleNode, TextNode, ButtonNode, ImageNode, InputNode,
    ASTVisitor
)

# Import code generators
from .codegen import (
    generate_html, generate_css, generate_js, generate_llvm,
    HTMLGenerator, CSSGenerator, JSGenerator, LLVMGenerator
)

__all__ = [
    # Lexer
    'Lexer', 'Token', 'TokenType', 'tokenize', 'LexerError',

    # Parser
    'Parser', 'parse', 'parse_file', 'ParserError',

    # Semantic
    'SemanticAnalyzer', 'analyze', 'SemanticError',

    # AST Nodes
    'ProgramNode', 'BaseNode', 'NodeType', 'Position',
    'PrintStatementNode', 'LetStatementNode', 'IfStatementNode',
    'LoopStatementNode', 'FunctionStatementNode', 'ReturnStatementNode',
    'ClassStatementNode', 'ImportStatementNode', 'AssignmentStatementNode',
    'IdentifierNode', 'StringLiteralNode', 'NumberLiteralNode', 'BooleanLiteralNode',
    'BinaryExpressionNode', 'CallExpressionNode', 'MemberExpressionNode',
    'PageNode', 'TitleNode', 'TextNode', 'ButtonNode', 'ImageNode', 'InputNode',
    'ASTVisitor',

    # Code Generators
    'generate_html', 'generate_css', 'generate_js', 'generate_llvm',
    'HTMLGenerator', 'CSSGenerator', 'JSGenerator', 'LLVMGenerator',
]

__version__ = '1.0.0'
__author__ = 'Mr.X Team'