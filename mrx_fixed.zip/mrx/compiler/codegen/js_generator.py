"""
Mr.X JavaScript Generator - Generates JavaScript code from AST

The JavaScript generator transforms Mr.X statements and expressions
into JavaScript code for web browser execution.

Author: Mr.X Team
"""

from typing import Dict, List, Optional, Any, Set
from ..ast_nodes import (
    BaseNode, ProgramNode, NodeType,
    PrintStatementNode, LetStatementNode, IfStatementNode, LoopStatementNode,
    WhileLoopStatementNode, FunctionStatementNode, ReturnStatementNode,
    ClassStatementNode, ImportStatementNode, AwaitStatementNode,
    ExpressionStatementNode, AssignmentStatementNode,
    IdentifierNode, StringLiteralNode, NumberLiteralNode, BooleanLiteralNode,
    NullLiteralNode, ArrayLiteralNode, ObjectLiteralNode,
    BinaryExpressionNode, UnaryExpressionNode, CallExpressionNode,
    MemberExpressionNode, IndexExpressionNode, TernaryExpressionNode,
    ArrowFunctionNode,
    PageNode, TitleNode, TextNode, ButtonNode, ImageNode, InputNode,
    NavNode, CardNode, SectionNode, FormNode, FooterNode, ContainerNode,
    GridNode, FlexNode, LinkNode, VideoNode
)


class JSGenerator:
    """
    Generates JavaScript code from Mr.X AST.

    The generator produces JavaScript that:
    - Handles all Mr.X language features
    - Provides web API integration
    - Supports async/await
    - Manages DOM manipulation
    - Handles events and interactivity
    """

    def __init__(self):
        self.output: List[str] = []
        self.functions: Dict[str, str] = {}
        self.classes: Dict[str, str] = {}
        self.variables: Set[str] = set()
        self.imports: List[str] = []
        self.current_indent = 0
        self.indent_size = 4
        self._init_builtins()

    def _init_builtins(self):
        """Initialize built-in functions and objects"""
        self.builtins = {
            'قول': 'console.log',
            'اطبع': 'console.log',
            'fetch': 'fetch',
            'JSON': 'JSON',
            'Math': 'Math',
            'document': 'document',
            'window': 'window',
            'console': 'console',
        }

    def _indent(self) -> str:
        """Get current indentation"""
        return " " * (self.current_indent * self.indent_size)

    def _increase_indent(self):
        """Increase indentation"""
        self.current_indent += 1

    def _decrease_indent(self):
        """Decrease indentation"""
        self.current_indent = max(0, self.current_indent - 1)

    def generate(self, ast: ProgramNode) -> str:
        """
        Generate JavaScript from AST.

        Args:
            ast: The AST to generate JavaScript from

        Returns:
            Complete JavaScript code as string
        """
        # Collect functions and classes first
        for statement in ast.statements:
            if isinstance(statement, FunctionStatementNode):
                self._collect_function(statement)
            elif isinstance(statement, ClassStatementNode):
                self._collect_class(statement)

        # Generate code for each statement
        for statement in ast.statements:
            code = self._generate_statement(statement)
            if code:
                self.output.append(code)

        # Combine all parts
        return self._build_js_code()

    def _collect_function(self, node: FunctionStatementNode):
        """Collect function code for later generation"""
        params = ", ".join(node.parameters)
        body = self._generate_function_body(node.body)

        is_async = "async " if node.is_async else ""
        func_code = f"{is_async}function {node.name}({params}) {{\n{body}\n}}"

        self.functions[node.name] = func_code

    def _collect_class(self, node: ClassStatementNode):
        """Collect class code for later generation"""
        base_classes = node.base_classes
        extends_clause = f" extends {base_classes[0]}" if base_classes else ""

        # Generate constructor
        constructor_params = []
        if node.constructor:
            constructor_params = node.constructor.parameters

        # Generate methods
        methods = []
        for method in node.methods:
            params = ", ".join(method.parameters)
            body = self._generate_function_body(method.body)
            is_async = "async " if method.is_async else ""
            methods.append(f"    {is_async}{method.name}({params}) {{\n{body}\n}}")

        class_code = f'''
class {node.name}{extends_clause} {{
    constructor({", ".join(constructor_params)}) {{
    }}
{chr(10).join(methods)}
}}
'''
        self.classes[node.name] = class_code

    def _generate_statement(self, node: BaseNode) -> str:
        """Generate code for a statement"""
        if isinstance(node, PrintStatementNode):
            return self._generate_print(node)
        elif isinstance(node, LetStatementNode):
            return self._generate_let(node)
        elif isinstance(node, AssignmentStatementNode):
            return self._generate_assignment(node)
        elif isinstance(node, IfStatementNode):
            return self._generate_if(node)
        elif isinstance(node, LoopStatementNode):
            return self._generate_loop(node)
        elif isinstance(node, WhileLoopStatementNode):
            return self._generate_while(node)
        elif isinstance(node, FunctionStatementNode):
            return ""  # Already collected
        elif isinstance(node, ReturnStatementNode):
            return self._generate_return(node)
        elif isinstance(node, ClassStatementNode):
            return ""  # Already collected
        elif isinstance(node, ImportStatementNode):
            return self._generate_import(node)
        elif isinstance(node, AwaitStatementNode):
            return self._generate_await(node)
        elif isinstance(node, ExpressionStatementNode):
            return self._generate_expression_statement(node)
        elif isinstance(node, PageNode):
            return self._generate_page(node)
        else:
            return ""

    def _generate_print(self, node: PrintStatementNode) -> str:
        """Generate print statement (قول)"""
        value = self._generate_expression(node.expression)
        return f"console.log({value});"

    def _generate_let(self, node: LetStatementNode) -> str:
        """Generate let statement (خلي)"""
        value = self._generate_expression(node.value)
        keyword = "const " if node.is_constant else "let "
        self.variables.add(node.name)
        return f"{keyword}{node.name} = {value};"

    def _generate_assignment(self, node: AssignmentStatementNode) -> str:
        """Generate assignment statement"""
        target = self._generate_expression(node.target)
        value = self._generate_expression(node.value)

        if node.operator == "=":
            return f"{target} = {value};"
        else:
            # Compound assignment (+=, -=, etc.)
            op = node.operator[:-1]  # Remove the '='
            return f"{target} {op}= {value};"

    def _generate_if(self, node: IfStatementNode) -> str:
        """Generate if statement (لو)"""
        condition = self._generate_expression(node.condition)
        then_branch = self._generate_block(node.then_branch)

        result = f"if ({condition}) {{\n{then_branch}\n}}"

        if node.else_branch:
            else_branch = self._generate_block(node.else_branch)
            result += f" else {{\n{else_branch}\n}}"

        return result

    def _generate_loop(self, node: LoopStatementNode) -> str:
        """Generate loop statement (كرر)"""
        count = self._generate_expression(node.count)
        body = self._generate_block(node.body)

        # Check if there's a loop variable
        if node.variable:
            return f"for (let {node.variable} = 0; {node.variable} < {count}; {node.variable}++) {{\n{body}\n}}"
        else:
            return f"for (let i = 0; i < {count}; i++) {{\n{body}\n}}"

    def _generate_while(self, node: WhileLoopStatementNode) -> str:
        """Generate while loop statement"""
        condition = self._generate_expression(node.condition)
        body = self._generate_block(node.body)

        return f"while ({condition}) {{\n{body}\n}}"

    def _generate_function_body(self, statements: List[BaseNode]) -> str:
        """Generate function body"""
        lines = []
        self._increase_indent()

        for stmt in statements:
            if isinstance(stmt, PrintStatementNode):
                value = self._generate_expression(stmt.expression)
                lines.append(f"console.log({value});")
            elif isinstance(stmt, ReturnStatementNode):
                if stmt.value:
                    value = self._generate_expression(stmt.value)
                    lines.append(f"return {value};")
                else:
                    lines.append("return;")
            elif isinstance(stmt, LetStatementNode):
                value = self._generate_expression(stmt.value)
                keyword = "const " if stmt.is_constant else "let "
                lines.append(f"{keyword}{stmt.name} = {value};")
            elif isinstance(stmt, IfStatementNode):
                lines.append(self._generate_if(stmt))
            elif isinstance(stmt, LoopStatementNode):
                lines.append(self._generate_loop(stmt))
            elif isinstance(stmt, ExpressionStatementNode):
                expr = self._generate_expression(stmt.expression)
                lines.append(f"{expr};")
            else:
                code = self._generate_statement(stmt)
                if code:
                    lines.append(code)

        self._decrease_indent()
        return "\n".join(f"    {line}" for line in lines)

    def _generate_return(self, node: ReturnStatementNode) -> str:
        """Generate return statement (ارجع)"""
        if node.value:
            value = self._generate_expression(node.value)
            return f"return {value};"
        return "return;"

    def _generate_import(self, node: ImportStatementNode) -> str:
        """Generate import statement (استورد)"""
        if node.items:
            items = ", ".join(node.items)
            return f"import {{{items}}} from '{node.module}';"
        elif node.alias:
            return f"import * as {node.alias} from '{node.module}';"
        else:
            return f"import '{node.module}';"

    def _generate_await(self, node: AwaitStatementNode) -> str:
        """Generate await statement"""
        expr = self._generate_expression(node.expression)
        return f"await {expr};"

    def _generate_expression_statement(self, node: ExpressionStatementNode) -> str:
        """Generate expression statement"""
        expr = self._generate_expression(node.expression)
        return f"{expr};"

    def _generate_page(self, node: PageNode) -> str:
        """Generate page initialization code"""
        # Page elements are handled in HTML generator
        return ""

    def _generate_block(self, statements: List[BaseNode]) -> str:
        """Generate a block of statements"""
        lines = []
        self._increase_indent()

        for stmt in statements:
            code = self._generate_statement(stmt)
            if code:
                lines.append(code)

        self._decrease_indent()
        return "\n".join(f"    {line}" for line in lines)

    def _generate_expression(self, node: BaseNode) -> str:
        """Generate code for an expression"""
        if isinstance(node, IdentifierNode):
            return node.name
        elif isinstance(node, StringLiteralNode):
            return f'"{self._escape_js_string(node.value)}"'
        elif isinstance(node, NumberLiteralNode):
            return str(node.value)
        elif isinstance(node, BooleanLiteralNode):
            return "true" if node.value else "false"
        elif isinstance(node, NullLiteralNode):
            return "null"
        elif isinstance(node, BinaryExpressionNode):
            return self._generate_binary_expression(node)
        elif isinstance(node, UnaryExpressionNode):
            return self._generate_unary_expression(node)
        elif isinstance(node, CallExpressionNode):
            return self._generate_call(node)
        elif isinstance(node, MemberExpressionNode):
            return self._generate_member(node)
        elif isinstance(node, IndexExpressionNode):
            return self._generate_index(node)
        elif isinstance(node, TernaryExpressionNode):
            return self._generate_ternary(node)
        elif isinstance(node, ArrayLiteralNode):
            return self._generate_array(node)
        elif isinstance(node, ObjectLiteralNode):
            return self._generate_object(node)
        elif isinstance(node, ArrowFunctionNode):
            return self._generate_arrow_function(node)
        else:
            return "undefined"

    def _generate_binary_expression(self, node: BinaryExpressionNode) -> str:
        """Generate binary expression"""
        left = self._generate_expression(node.left)
        right = self._generate_expression(node.right)
        return f"({left} {node.operator} {right})"

    def _generate_unary_expression(self, node: UnaryExpressionNode) -> str:
        """Generate unary expression"""
        operand = self._generate_expression(node.operand)

        if node.operator == "not" or node.operator == "ليس":
            return f"(!{operand})"
        elif node.operator == "-":
            return f"(-{operand})"
        else:
            return f"({node.operator}{operand})"

    def _generate_call(self, node: CallExpressionNode) -> str:
        """Generate function call"""
        callee = self._generate_expression(node.callee)
        args = [self._generate_expression(arg) for arg in node.arguments]
        return f"{callee}({', '.join(args)})"

    def _generate_member(self, node: MemberExpressionNode) -> str:
        """Generate member access"""
        obj = self._generate_expression(node.object)
        return f"{obj}.{node.property}"

    def _generate_index(self, node: IndexExpressionNode) -> str:
        """Generate index access"""
        obj = self._generate_expression(node.object)
        index = self._generate_expression(node.index)
        return f"{obj}[{index}]"

    def _generate_ternary(self, node: TernaryExpressionNode) -> str:
        """Generate ternary expression"""
        condition = self._generate_expression(node.condition)
        then_expr = self._generate_expression(node.then_expr)
        else_expr = self._generate_expression(node.else_expr)
        return f"({condition} ? {then_expr} : {else_expr})"

    def _generate_array(self, node: ArrayLiteralNode) -> str:
        """Generate array literal"""
        elements = [self._generate_expression(elem) for elem in node.elements]
        return f"[{', '.join(elements)}]"

    def _generate_object(self, node: ObjectLiteralNode) -> str:
        """Generate object literal"""
        props = []
        for key, value in node.properties.items():
            val = self._generate_expression(value)
            props.append(f"{key}: {val}")
        return f"{{{', '.join(props)}}}"

    def _generate_arrow_function(self, node: ArrowFunctionNode) -> str:
        """Generate arrow function"""
        params = ", ".join(node.parameters)
        body = node.body

        if isinstance(body, BaseNode):
            body_code = self._generate_expression(body)
            return f"({params}) => {body_code}"
        else:
            body_code = self._generate_block(body)
            return f"({params}) => {{\n{body_code}\n}}"

    def _escape_js_string(self, s: str) -> str:
        """Escape special characters in JavaScript string"""
        return (s
                .replace("\\", "\\\\")
                .replace('"', '\\"')
                .replace("'", "\\'")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t"))

    def _build_js_code(self) -> str:
        """Build the complete JavaScript code"""
        parts = []

        # Add use strict
        parts.append('"use strict";')
        parts.append("")

        # Add class definitions
        for class_code in self.classes.values():
            parts.append(class_code)
            parts.append("")

        # Add function definitions
        for func_code in self.functions.values():
            parts.append(func_code)
            parts.append("")

        # Add main code
        if self.output:
            parts.append("// Main code")
            parts.extend(self.output)

        return "\n".join(parts)


def generate_js(ast: ProgramNode) -> str:
    """
    Generate JavaScript from AST.

    Args:
        ast: The AST to generate JavaScript from

    Returns:
        Complete JavaScript code as string
    """
    generator = JSGenerator()
    return generator.generate(ast)


if __name__ == "__main__":
    # Test JavaScript generation
    from ..parser import parse

    test_code = '''
خلي name = "Mohsen"
قول "مرحبا" + name

لو name == "Mohsen":
    قول "owner"

دالة greet(msg):
    ارجع "مرحبا: " + msg

كرر 5:
    قول "iteration"
'''

    ast = parse(test_code)
    generator = JSGenerator()
    js = generator.generate(ast)
    print(js)