"""
Mr.X LLVM Generator - Generates LLVM IR for native compilation

This module provides infrastructure for future native code generation
using the LLVM compiler infrastructure.

Author: Mr.X Team
"""

from typing import Dict, List, Optional, Set
from ..ast_nodes import (
    BaseNode, ProgramNode, NodeType,
    PrintStatementNode, LetStatementNode, IfStatementNode, LoopStatementNode,
    FunctionStatementNode, ReturnStatementNode, ClassStatementNode,
    IdentifierNode, StringLiteralNode, NumberLiteralNode, BooleanLiteralNode,
    BinaryExpressionNode, CallExpressionNode, MemberExpressionNode
)


class LLVMType:
    """LLVM type representation"""
    VOID = "void"
    INT = "i32"
    INT64 = "i64"
    FLOAT = "float"
    DOUBLE = "double"
    BOOL = "i1"
    CHAR = "i8"
    POINTER = "ptr"
    ARRAY = "array"
    FUNCTION = "function"

    # Arabic types to LLVM types
    TYPE_MAP = {
        "عدد": INT,
        "نص": "ptr",  # String as pointer
        "منطقي": BOOL,
        "فارغ": VOID,
        "object": POINTER,
        "function": POINTER,
    }

    @classmethod
    def from_mrx_type(cls, mrx_type: str) -> str:
        """Convert Mr.X type to LLVM type"""
        return cls.TYPE_MAP.get(mrx_type, cls.INT)


class LLVMValue:
    """Represents an LLVM value/constant"""
    def __init__(self, name: str, llvm_type: str):
        self.name = name
        self.llvm_type = llvm_type


class LLVMGenerator:
    """
    Generates LLVM IR code from Mr.X AST.

    This is a foundation for future native compilation support.
    Currently generates placeholder IR that can be extended.

    Target features:
    - Function compilation
    - Variable allocation
    - Arithmetic operations
    - Control flow
    - Function calls
    - Class/struct support
    - Memory management
    """

    def __init__(self):
        self.module_name = "mrx_module"
        self.output: List[str] = []
        self.functions: Dict[str, str] = {}
        self.global_variables: Dict[str, str] = {}
        self.local_variables: Dict[str, LLVMValue] = {}
        self.current_function: Optional[str] = None
        self.label_counter = 0
        self.variable_counter = 0
        self._init_builtins()

    def _init_builtins(self):
        """Initialize built-in functions"""
        self.builtin_functions = {
            'قول': ('void', [('i8', 'ptr')]),
            'اطبع': ('void', [('i8', 'ptr')]),
        }

    def _new_label(self, prefix: str = "label") -> str:
        """Generate a new unique label"""
        self.label_counter += 1
        return f"{prefix}{self.label_counter}"

    def _new_variable(self, prefix: str = "v") -> str:
        """Generate a new unique variable name"""
        self.variable_counter += 1
        return f"%{prefix}{self.variable_counter}"

    def generate(self, ast: ProgramNode) -> str:
        """
        Generate LLVM IR from AST.

        Args:
            ast: The AST to generate LLVM IR from

        Returns:
            Complete LLVM IR module as string
        """
        # Generate header
        self._generate_header()

        # Generate declarations for all functions
        for statement in ast.statements:
            if isinstance(statement, FunctionStatementNode):
                self._declare_function(statement)

        # Generate function implementations
        for statement in ast.statements:
            if isinstance(statement, FunctionStatementNode):
                self._generate_function(statement)

        # Generate main function
        self._generate_main(ast)

        return self._build_module()

    def _generate_header(self):
        """Generate module header"""
        self.output.append("; Mr.X Generated LLVM IR")
        self.output.append(f"; Module: {self.module_name}")
        self.output.append("")
        self.output.append("target datalayout = \"e-m:e-i64:64-f80:128-n8:16:32:64-S128\"")
        self.output.append("target triple = \"x86_64-unknown-linux-gnu\"")
        self.output.append("")

        # Declare external functions
        self._declare_external_functions()

    def _declare_external_functions(self):
        """Declare external C library functions"""
        self.output.append("; External function declarations")
        self.output.append("declare i32 @printf(i8*, ...)")
        self.output.append("declare i8* @malloc(i64)")
        self.output.append("declare void @free(i8*)")
        self.output.append("")

    def _declare_function(self, node: FunctionStatementNode):
        """Declare a function (forward declaration)"""
        return_type = LLVMType.VOID  # Default return type
        param_types = [LLVMType.INT] * len(node.parameters)  # Default to int

        # Check for builtin functions
        if node.name in self.builtin_functions:
            return_type, param_types = self.builtin_functions[node.name]

        params = ", ".join(param_types)
        self.output.append(f"declare {return_type} @{node.name}({params})")

    def _generate_function(self, node: FunctionStatementNode):
        """Generate function implementation"""
        return_type = LLVMType.VOID
        param_types = [LLVMType.INT] * len(node.parameters)

        # Check for builtin functions
        if node.name in self.builtin_functions:
            return_type, param_types = self.builtin_functions[node.name]

        # Create parameter list with names
        params = []
        for i, param in enumerate(node.parameters):
            param_name = f"%arg{i}"
            params.append(f"{param_types[i]} {param_name}")

        # Function signature
        signature = f"define {return_type} @{node.name}({', '.join(params)}) {{"

        # Clear local variables for this function
        self.local_variables.clear()
        self.current_function = node.name

        # Generate function body
        body = self._generate_function_body(node.body, node.parameters)

        # Combine
        self.functions[node.name] = f"{signature}\n{body}\n}}"

    def _generate_function_body(self, statements: List[BaseNode], parameters: List[str]) -> str:
        """Generate function body"""
        lines = []

        # Allocate parameters
        for i, param in enumerate(parameters):
            var_ptr = self._new_variable("ptr")
            lines.append(f"    {var_ptr} = alloca i32")
            lines.append(f"    store i32 %arg{i}, i32* {var_ptr}")
            self.local_variables[param] = LLVMValue(var_ptr, LLVMType.INT)

        # Generate statements
        for stmt in statements:
            code = self._generate_statement(stmt)
            if code:
                lines.append(f"    {code}")

        # Default return for void functions
        lines.append("    ret void")

        return "\n".join(lines)

    def _generate_statement(self, node: BaseNode) -> str:
        """Generate code for a statement"""
        if isinstance(node, PrintStatementNode):
            return self._generate_print(node)
        elif isinstance(node, LetStatementNode):
            return self._generate_let(node)
        elif isinstance(node, ReturnStatementNode):
            return self._generate_return(node)
        elif isinstance(node, IfStatementNode):
            return self._generate_if(node)
        elif isinstance(node, LoopStatementNode):
            return self._generate_loop(node)
        return ""

    def _generate_print(self, node: PrintStatementNode) -> str:
        """Generate print statement"""
        value = self._generate_expression(node.expression)
        return f"call i32 (i8*, ...) @printf(i8* getelementptr inbounds ([5 x i8], [5 x i8]* @.str, i64 0, i64 0), i32 {value})"

    def _generate_let(self, node: LetStatementNode) -> str:
        """Generate let statement"""
        var_ptr = self._new_variable("ptr")
        value = self._generate_expression(node.value)

        self.local_variables[node.name] = LLVMValue(var_ptr, LLVMType.INT)

        lines = []
        lines.append(f"{var_ptr} = alloca i32")
        lines.append(f"store i32 {value}, i32* {var_ptr}")

        return "\n    ".join(lines)

    def _generate_return(self, node: ReturnStatementNode) -> str:
        """Generate return statement"""
        if node.value:
            value = self._generate_expression(node.value)
            return f"ret i32 {value}"
        return "ret void"

    def _generate_if(self, node: IfStatementNode) -> str:
        """Generate if statement"""
        condition = self._generate_expression(node.condition)
        then_label = self._new_label("then")
        else_label = self._new_label("else")
        end_label = self._new_label("endif")

        lines = []
        lines.append(f"br i1 {condition}, label %{then_label}, label %{else_label}")
        lines.append(f"{then_label}:")
        lines.append(f"{self._generate_block(node.then_branch)}")
        lines.append(f"br label %{end_label}")
        lines.append(f"{else_label}:")

        if node.else_branch:
            lines.append(f"{self._generate_block(node.else_branch)}")

        lines.append(f"br label %{end_label}")
        lines.append(f"{end_label}:")

        return "\n    ".join(lines)

    def _generate_loop(self, node: LoopStatementNode) -> str:
        """Generate loop statement"""
        count = self._generate_expression(node.count)
        loop_label = self._new_label("loop")
        check_label = self._new_label("check")
        end_label = self._new_label("endloop")

        lines = []
        lines.append(f"br label %{check_label}")
        lines.append(f"{check_label}:")

        # Loop counter
        counter_ptr = self._new_variable("ptr")
        counter = self._new_variable("counter")
        lines.append(f"{counter_ptr} = alloca i32")
        lines.append(f"store i32 0, i32* {counter_ptr}")
        lines.append(f"{counter} = load i32, i32* {counter_ptr}")

        lines.append(f"icmp slt i32 {counter}, {count}")
        lines.append(f"br i1 %cmp, label %{loop_label}, label %{end_label}")
        lines.append(f"{loop_label}:")
        lines.append(f"{self._generate_block(node.body)}")
        lines.append(f"{counter} = add i32 {counter}, 1")
        lines.append(f"store i32 {counter}, i32* {counter_ptr}")
        lines.append(f"br label %{check_label}")
        lines.append(f"{end_label}:")

        return "\n    ".join(lines)

    def _generate_block(self, statements: List[BaseNode]) -> str:
        """Generate a block of statements"""
        lines = []
        for stmt in statements:
            code = self._generate_statement(stmt)
            if code:
                lines.append(code)
        return "\n    ".join(lines)

    def _generate_expression(self, node: BaseNode) -> str:
        """Generate code for an expression"""
        if isinstance(node, IdentifierNode):
            var = self.local_variables.get(node.name)
            if var:
                return f"load i32, i32* {var.name}"
            return "%0"  # Default value
        elif isinstance(node, NumberLiteralNode):
            return str(int(node.value))
        elif isinstance(node, BinaryExpressionNode):
            return self._generate_binary_expression(node)
        elif isinstance(node, CallExpressionNode):
            return self._generate_call(node)
        return "0"

    def _generate_binary_expression(self, node: BinaryExpressionNode) -> str:
        """Generate binary expression"""
        left = self._generate_expression(node.left)
        right = self._generate_expression(node.right)

        result = self._new_variable("result")

        op_map = {
            '+': 'add',
            '-': 'sub',
            '*': 'mul',
            '/': 'sdiv',
            '%': 'srem',
            '==': 'icmp eq',
            '!=': 'icmp ne',
            '<': 'icmp slt',
            '>': 'icmp sgt',
            '<=': 'icmp sle',
            '>=': 'icmp sge',
        }

        llvm_op = op_map.get(node.operator, 'add')

        if llvm_op.startswith('icmp'):
            return f"{llvm_op} i32 {left}, {right}"
        else:
            return f"{result} = {llvm_op} i32 {left}, {right}\n    {result}"

    def _generate_call(self, node: CallExpressionNode) -> str:
        """Generate function call"""
        callee = node.callee
        if isinstance(callee, IdentifierNode):
            func_name = callee.name
            args = [self._generate_expression(arg) for arg in node.arguments]
            result = self._new_variable("callresult")
            return f"{result} = call i32 @{func_name}({', '.join(args)})\n    {result}"
        return "0"

    def _generate_main(self, ast: ProgramNode):
        """Generate main function"""
        main_body = []

        # Generate code for non-function statements
        for statement in ast.statements:
            if not isinstance(statement, FunctionStatementNode):
                code = self._generate_statement(statement)
                if code:
                    main_body.append(f"    {code}")

        main_body.append("    ret i32 0")

        self.output.append("; Main function")
        self.output.append("define i32 @main() {")
        self.output.extend(main_body)
        self.output.append("}")
        self.output.append("")

    def _build_module(self) -> str:
        """Build the complete LLVM module"""
        parts = []

        # Header
        parts.append("; Mr.X LLVM IR Module")
        parts.append(f"; Generated for module: {self.module_name}")
        parts.append("")

        # Add function definitions
        for func_code in self.functions.values():
            parts.append(func_code)
            parts.append("")

        # Add remaining output
        for line in self.output:
            if line and not line.startswith("declare "):
                parts.append(line)

        return "\n".join(parts)


def generate_llvm(ast: ProgramNode, module_name: str = "mrx_module") -> str:
    """
    Generate LLVM IR from AST.

    Args:
        ast: The AST to generate LLVM IR from
        module_name: Name of the LLVM module

    Returns:
        Complete LLVM IR module as string
    """
    generator = LLVMGenerator()
    generator.module_name = module_name
    return generator.generate(ast)


def compile_to_object(llvm_ir: str, output_file: str = "output.o") -> bool:
    """
    Compile LLVM IR to object file using llc.

    Args:
        llvm_ir: LLVM IR code
        output_file: Output object file path

    Returns:
        True if compilation succeeded
    """
    # This would use llc in a real implementation
    # import subprocess
    # result = subprocess.run(['llc', '-filetype=obj', '-o', output_file],
    #                        input=llvm_ir, capture_output=True)
    # return result.returncode == 0
    return False


def link_executable(object_files: List[str], output_file: str = "a.out") -> bool:
    """
    Link object files into an executable.

    Args:
        object_files: List of object file paths
        output_file: Output executable path

    Returns:
        True if linking succeeded
    """
    # This would use lld or gcc in a real implementation
    # import subprocess
    # result = subprocess.run(['ld', '-o', output_file] + object_files,
    #                        capture_output=True)
    # return result.returncode == 0
    return False


if __name__ == "__main__":
    # Test LLVM generation
    from ..parser import parse

    test_code = '''
خلي x = 10
قول x

دالة add(a, b):
    ارجع a + b
'''

    ast = parse(test_code)
    generator = LLVMGenerator()
    llvm_ir = generator.generate(ast)
    print(llvm_ir)