"""
Mr.X HTML Generator - Generates HTML structure from AST

The HTML generator transforms web element nodes into HTML markup.
It supports all Mr.X web framework elements.

Author: Mr.X Team
"""

from typing import Dict, List, Optional, Any
from ..ast_nodes import (
    BaseNode, ProgramNode, NodeType,
    PageNode, TitleNode, TextNode, ButtonNode, ImageNode, InputNode,
    NavNode, CardNode, SectionNode, FormNode, FooterNode, ContainerNode,
    GridNode, FlexNode, LinkNode, VideoNode,
    PrintStatementNode, LetStatementNode, IfStatementNode, LoopStatementNode,
    FunctionStatementNode, ExpressionStatementNode, IdentifierNode,
    StringLiteralNode, NumberLiteralNode, BinaryExpressionNode,
    CallExpressionNode, AssignmentStatementNode
)


class HTMLGenerator:
    """
    Generates HTML code from Mr.X AST.

    The generator traverses the AST and produces HTML markup
    for web elements and standard statements.
    """

    def __init__(self, indent_size: int = 2):
        self.indent_size = indent_size
        self.indent_level = 0
        self.output: List[str] = []
        self.head_content: List[str] = []
        self.body_content: List[str] = []
        self.js_code: List[str] = []
        self.page_title = "Mr.X Page"
        self.page_language = "ar"
        self.dark_mode = False
        self.component_counter = 0
        self.style_classes: Dict[str, str] = {}
        self.generated_ids: set = set()

    def _indent(self) -> str:
        """Get indentation string"""
        return " " * (self.indent_level * self.indent_size)

    def _generate_id(self, prefix: str = "mrx") -> str:
        """Generate a unique ID"""
        self.component_counter += 1
        return f"{prefix}-{self.component_counter}"

    def generate(self, ast: ProgramNode) -> str:
        """
        Generate HTML from AST.

        Args:
            ast: The AST to generate HTML from

        Returns:
            Complete HTML document as string
        """
        # Process all statements
        for statement in ast.statements:
            self._visit_statement(statement)

        # Build the final HTML document
        return self._build_html_document()

    def _visit_statement(self, node: BaseNode):
        """Visit a statement node"""
        if isinstance(node, PageNode):
            self._visit_page(node)
        elif isinstance(node, PrintStatementNode):
            self._visit_print_statement(node)
        elif isinstance(node, LetStatementNode):
            self._visit_let_statement(node)
        elif isinstance(node, IfStatementNode):
            self._visit_if_statement(node)
        elif isinstance(node, LoopStatementNode):
            self._visit_loop_statement(node)
        elif isinstance(node, FunctionStatementNode):
            self._visit_function_statement(node)
        elif isinstance(node, ExpressionStatementNode):
            self._visit_expression_statement(node)
        else:
            # Check for web elements
            if hasattr(node, 'node_type'):
                self._visit_web_element(node)

    def _visit_page(self, node: PageNode):
        """Visit a page node"""
        self.page_title = node.title or node.name
        self.page_language = getattr(node, 'language', 'ar')
        self.dark_mode = getattr(node, 'dark_mode', False)

        # Process children
        for child in node.children:
            self._visit_statement(child)

    def _visit_print_statement(self, node: PrintStatementNode):
        """Visit a print statement"""
        value = self._evaluate_expression(node.expression)
        if value is not None:
            self.body_content.append(f'<div class="mrx-output">{self._escape_html(str(value))}</div>')

    def _visit_let_statement(self, node: LetStatementNode):
        """Visit a let statement"""
        # Variables are handled in JavaScript
        pass

    def _visit_if_statement(self, node: IfStatementNode):
        """Visit an if statement"""
        condition = self._generate_condition(node.condition)
        then_content = self._generate_block(node.then_branch)
        else_content = self._generate_block(node.else_branch) if node.else_branch else ""

        script = f'''
if ({condition}) {{
    {then_content}
}}{f' else {{ {else_content} }}' if else_content else ''}
'''
        self.js_code.append(script)

    def _visit_loop_statement(self, node: LoopStatementNode):
        """Visit a loop statement"""
        count = self._evaluate_expression(node.count)
        body_content = self._generate_block(node.body)

        script = f'''
for (let i = 0; i < {count}; i++) {{
    {body_content}
}}
'''
        self.js_code.append(script)

    def _visit_function_statement(self, node: FunctionStatementNode):
        """Visit a function statement"""
        params = ", ".join(node.parameters)
        body_content = self._generate_function_body(node.body)

        script = f'''
function {node.name}({params}) {{
    {body_content}
}}
'''
        self.js_code.append(script)

    def _visit_expression_statement(self, node):
        """Visit an expression statement"""
        pass

    def _visit_web_element(self, node: BaseNode):
        """Visit a web element"""
        if isinstance(node, TitleNode):
            self._visit_title(node)
        elif isinstance(node, TextNode):
            self._visit_text(node)
        elif isinstance(node, ButtonNode):
            self._visit_button(node)
        elif isinstance(node, ImageNode):
            self._visit_image(node)
        elif isinstance(node, InputNode):
            self._visit_input(node)
        elif isinstance(node, NavNode):
            self._visit_nav(node)
        elif isinstance(node, CardNode):
            self._visit_card(node)
        elif isinstance(node, SectionNode):
            self._visit_section(node)
        elif isinstance(node, FormNode):
            self._visit_form(node)
        elif isinstance(node, FooterNode):
            self._visit_footer(node)
        elif isinstance(node, LinkNode):
            self._visit_link(node)
        elif isinstance(node, ContainerNode):
            self._visit_container(node)
        elif isinstance(node, GridNode):
            self._visit_grid(node)
        elif isinstance(node, FlexNode):
            self._visit_flex(node)
        elif isinstance(node, VideoNode):
            self._visit_video(node)

    def _visit_title(self, node: TitleNode):
        """عنوان - Heading element"""
        level = getattr(node, 'level', 1) or 1
        text = self._get_text_content(node)
        self.body_content.append(f'<h{level} class="mrx-title">{self._escape_html(text)}</h{level}>')

    def _visit_text(self, node: TextNode):
        """نص - Text content"""
        text = self._get_text_content(node)
        classes = " ".join(node.classes) if node.classes else "mrx-text"
        self.body_content.append(f'<p class="{classes}">{self._escape_html(text)}</p>')

    def _visit_button(self, node: ButtonNode):
        """زر - Button element"""
        text = getattr(node, 'text', '') or self._get_text_content(node)
        element_id = node.element_id or self._generate_id("btn")

        classes = " ".join(node.classes) + " mrx-button" if node.classes else "mrx-button"

        onclick = ""
        if node.on_click:
            onclick = f' onclick="{node.on_click}"'

        self.body_content.append(
            f'<button id="{element_id}" class="{classes}"{onclick}>{self._escape_html(text)}</button>'
        )

    def _visit_image(self, node: ImageNode):
        """صورة - Image element"""
        src = getattr(node, 'src', '') or node.name
        alt = getattr(node, 'alt', '') or "Image"
        element_id = node.element_id or self._generate_id("img")

        classes = " ".join(node.classes) + " mrx-image" if node.classes else "mrx-image"

        self.body_content.append(
            f'<img id="{element_id}" src="{src}" alt="{self._escape_html(alt)}" class="{classes}">'
        )

    def _visit_input(self, node: InputNode):
        """حقل - Input field"""
        input_type = getattr(node, 'input_type', 'text') or 'text'
        placeholder = getattr(node, 'placeholder', '') or getattr(node, 'label', '') or ""
        label = getattr(node, 'label', '') or ""
        element_id = node.element_id or self._generate_id("input")

        classes = " ".join(node.classes) + " mrx-input" if node.classes else "mrx-input"

        html = f'<div class="mrx-input-wrapper">'
        if label:
            html += f'<label for="{element_id}" class="mrx-label">{self._escape_html(label)}</label>'
        html += f'<input type="{input_type}" id="{element_id}" placeholder="{self._escape_html(placeholder)}" class="{classes}">'
        html += '</div>'

        self.body_content.append(html)

    def _visit_nav(self, node: NavNode):
        """قائمة - Navigation bar"""
        element_id = node.element_id or self._generate_id("nav")

        html = f'<nav id="{element_id}" class="mrx-nav">'
        html += '<div class="mrx-nav-container">'

        # Process children
        for child in node.children:
            self._visit_web_element(child)

        html += '</div>'
        html += '</nav>'

        self.body_content.append(html)

    def _visit_card(self, node: CardNode):
        """بطاقة - Card component"""
        element_id = node.element_id or self._generate_id("card")

        html = f'<div id="{element_id}" class="mrx-card">'
        html += '<div class="mrx-card-content">'

        # Process children
        for child in node.children:
            self._visit_web_element(child)

        html += '</div>'
        html += '</div>'

        self.body_content.append(html)

    def _visit_section(self, node: SectionNode):
        """قسم - Section"""
        element_id = node.element_id or self._generate_id("section")

        html = f'<section id="{element_id}" class="mrx-section">'

        # Process children
        for child in node.children:
            self._visit_web_element(child)

        html += '</section>'

        self.body_content.append(html)

    def _visit_form(self, node: FormNode):
        """نموذج - Form"""
        action = getattr(node, 'action', '') or "#"
        method = getattr(node, 'method', 'POST') or 'POST'
        element_id = node.element_id or self._generate_id("form")

        html = f'<form id="{element_id}" action="{action}" method="{method}" class="mrx-form">'

        # Process children
        for child in node.children:
            self._visit_web_element(child)

        html += '</form>'

        self.body_content.append(html)

    def _visit_footer(self, node: FooterNode):
        """تذييل - Footer"""
        element_id = node.element_id or self._generate_id("footer")

        html = f'<footer id="{element_id}" class="mrx-footer">'

        # Process children
        for child in node.children:
            self._visit_web_element(child)

        html += '</footer>'

        self.body_content.append(html)

    def _visit_link(self, node: LinkNode):
        """رابط - Hyperlink"""
        href = getattr(node, 'href', '') or "#"
        text = getattr(node, 'text', '') or self._get_text_content(node)
        element_id = node.element_id or self._generate_id("link")

        classes = " ".join(node.classes) + " mrx-link" if node.classes else "mrx-link"

        self.body_content.append(
            f'<a id="{element_id}" href="{href}" class="{classes}">{self._escape_html(text)}</a>'
        )

    def _visit_container(self, node: ContainerNode):
        """حاوية - Container"""
        element_id = node.element_id or self._generate_id("container")

        html = f'<div id="{element_id}" class="mrx-container">'

        # Process children
        for child in node.children:
            self._visit_web_element(child)

        html += '</div>'

        self.body_content.append(html)

    def _visit_grid(self, node: GridNode):
        """شبكة - Grid layout"""
        columns = getattr(node, 'columns', 3) or 3
        element_id = node.element_id or self._generate_id("grid")

        html = f'<div id="{element_id}" class="mrx-grid" style="grid-template-columns: repeat({columns}, 1fr);">'

        # Process children
        for child in node.children:
            self._visit_web_element(child)

        html += '</div>'

        self.body_content.append(html)

    def _visit_flex(self, node: FlexNode):
        """مرن - Flexbox layout"""
        direction = getattr(node, 'direction', 'row') or 'row'
        align = getattr(node, 'align', 'center') or 'center'
        justify = getattr(node, 'justify', 'center') or 'center'
        element_id = node.element_id or self._generate_id("flex")

        html = f'<div id="{element_id}" class="mrx-flex" style="flex-direction: {direction}; align-items: {align}; justify-content: {justify};">'

        # Process children
        for child in node.children:
            self._visit_web_element(child)

        html += '</div>'

        self.body_content.append(html)

    def _visit_video(self, node: VideoNode):
        """فيديو - Video element"""
        src = getattr(node, 'src', '') or node.name
        autoplay = getattr(node, 'autoplay', False)
        controls = getattr(node, 'controls', True)
        element_id = node.element_id or self._generate_id("video")

        classes = " ".join(node.classes) + " mrx-video" if node.classes else "mrx-video"

        autoplay_attr = " autoplay" if autoplay else ""
        controls_attr = " controls" if controls else ""

        self.body_content.append(
            f'<video id="{element_id}" src="{src}" class="{classes}"{autoplay_attr}{controls_attr}></video>'
        )

    def _get_text_content(self, node: BaseNode) -> str:
        """Get text content from a node"""
        if isinstance(node, StringLiteralNode):
            return node.value
        elif hasattr(node, 'name'):
            return node.name
        elif hasattr(node, 'text'):
            return node.text
        else:
            return ""

    def _evaluate_expression(self, node) -> str:
        """Evaluate an expression to a string value"""
        if isinstance(node, StringLiteralNode):
            return f'"{node.value}"'
        elif isinstance(node, NumberLiteralNode):
            return str(node.value)
        elif isinstance(node, IdentifierNode):
            return node.name
        elif isinstance(node, BinaryExpressionNode):
            left = self._evaluate_expression(node.left)
            right = self._evaluate_expression(node.right)
            return f"({left} {node.operator} {right})"
        elif isinstance(node, CallExpressionNode):
            args = [self._evaluate_expression(a) for a in node.arguments]
            callee = self._evaluate_expression(node.callee)
            return f"{callee}({', '.join(args)})"
        else:
            return "null"

    def _generate_condition(self, node) -> str:
        """Generate a JavaScript condition"""
        return self._evaluate_expression(node)

    def _generate_block(self, statements: List[BaseNode]) -> str:
        """Generate JavaScript code for a block of statements"""
        lines = []
        for stmt in statements:
            if isinstance(stmt, PrintStatementNode):
                value = self._evaluate_expression(stmt.expression)
                lines.append(f'console.log({value});')
        return "\n    ".join(lines)

    def _generate_function_body(self, statements: List[BaseNode]) -> str:
        """Generate JavaScript code for a function body"""
        lines = []
        for stmt in statements:
            if isinstance(stmt, PrintStatementNode):
                value = self._evaluate_expression(stmt.expression)
                lines.append(f'console.log({value});')
            elif isinstance(stmt, ReturnStatementNode):
                if stmt.value:
                    value = self._evaluate_expression(stmt.value)
                    lines.append(f'return {value};')
        return "\n    ".join(lines)

    def _escape_html(self, text: str) -> str:
        """Escape HTML special characters"""
        return (text
                .replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace('"', "&quot;")
                .replace("'", "&#39;"))

    def _build_html_document(self) -> str:
        """Build the complete HTML document"""
        # Add meta tags
        self.head_content.append('<meta charset="UTF-8">')
        self.head_content.append('<meta name="viewport" content="width=device-width, initial-scale=1.0">')
        self.head_content.append(f'<title>{self._escape_html(self.page_title)}</title>')

        # Add CSS link
        self.head_content.append('<link rel="stylesheet" href="style.css">')

        # Add RTL support for Arabic
        if self.page_language == "ar":
            self.head_content.append('<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.rtl.min.css">')

        # Build HTML
        html = '<!DOCTYPE html>\n'
        html += f'<html lang="{self.page_language}">\n'
        html += '<head>\n'
        html += "\n".join(f"    {line}" for line in self.head_content)
        html += '\n</head>\n'
        html += f'<body class="{"dark-mode" if self.dark_mode else ""}">\n'
        html += '<div class="mrx-app">\n'

        # Add body content
        for line in self.body_content:
            html += f"    {line}\n"

        html += '</div>\n'

        # Add JavaScript
        html += '<script>\n'
        html += "// Mr.X Generated JavaScript\n"
        html += "\n".join(f"    {line}" for line in self.js_code)
        html += '\n</script>\n'
        html += '</body>\n'
        html += '</html>'

        return html


def generate_html(ast: ProgramNode) -> str:
    """
    Generate HTML from AST.

    Args:
        ast: The AST to generate HTML from

    Returns:
        Complete HTML document as string
    """
    generator = HTMLGenerator()
    return generator.generate(ast)


if __name__ == "__main__":
    # Test HTML generation
    from ..parser import parse

    test_code = '''
صفحة "Coffee"

عنوان "أفضل قهوة"

نص "مرحبا بكم في عالم القهوة"

زر "اطلب الآن"
'''

    ast = parse(test_code)
    generator = HTMLGenerator()
    html = generator.generate(ast)
    print(html)