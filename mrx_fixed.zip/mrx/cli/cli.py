"""
Mr.X CLI - Command Line Interface

A comprehensive CLI tool for the Mr.X programming language supporting:
- Project creation
- Code compilation
- Running programs
- Building web applications
- Development server

Author: Mr.X Team
"""

import sys
import os
import argparse
import shutil
from pathlib import Path
from typing import Optional, List
import json

# Add project root to path
PROJECT_ROOT = Path(__file__).parent.parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from compiler.parser import parse, parse_file, Parser
from compiler.semantic import analyze
from compiler.codegen.html_generator import generate_html
from compiler.codegen.css_generator import generate_css
from compiler.codegen.js_generator import generate_js
from compiler.codegen.llvm_generator import generate_llvm
from runtime.runtime import execute, Runtime


class Colors:
    """ANSI color codes for terminal output"""
    RESET = "\033[0m"
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    MAGENTA = "\033[95m"
    CYAN = "\033[96m"
    WHITE = "\033[97m"
    BOLD = "\033[1m"
    DIM = "\033[2m"


def color(text: str, color_code: str) -> str:
    """Apply color to text"""
    return f"{color_code}{text}{Colors.RESET}"


def print_header(text: str):
    """Print a header with styling"""
    print(color(f"\n{'=' * 60}", Colors.CYAN))
    print(color(f"  {text}", Colors.BOLD + Colors.CYAN))
    print(color(f"{'=' * 60}\n", Colors.CYAN))


def print_success(text: str):
    """Print success message"""
    print(color(f"✓ {text}", Colors.GREEN))


def print_error(text: str):
    """Print error message"""
    print(color(f"✗ {text}", Colors.RED))


def print_info(text: str):
    """Print info message"""
    print(color(f"ℹ {text}", Colors.BLUE))


def print_warning(text: str):
    """Print warning message"""
    print(color(f"⚠ {text}", Colors.YELLOW))


class Compiler:
    """Mr.X Compiler - Compiles .mrx files to various outputs"""

    def __init__(self):
        self.parser = Parser()
        self.errors: List[str] = []
        self.warnings: List[str] = []

    def compile_file(self, filepath: str, output_dir: str = "output", target: str = "web") -> bool:
        """
        Compile a .mrx file.

        Args:
            filepath: Path to the source file
            output_dir: Output directory
            target: Target platform ("web", "console", "llvm")

        Returns:
            True if compilation succeeded
        """
        print_info(f"Compiling {filepath}...")

        try:
            # Parse the file
            ast = self.parser.parse_file(filepath)

            # Analyze
            ast = analyze(ast, filepath)

            # Create output directory
            output_path = Path(output_dir)
            output_path.mkdir(exist_ok=True, parents=True)

            if target == "web":
                return self._compile_web(ast, output_path)
            elif target == "console":
                return self._compile_console(ast, output_path)
            elif target == "llvm":
                return self._compile_llvm(ast, output_path)
            else:
                print_error(f"Unknown target: {target}")
                return False

        except Exception as e:
            print_error(f"Compilation failed: {e}")
            return False

    def _compile_web(self, ast, output_path: Path) -> bool:
        """Compile to web (HTML, CSS, JS)"""
        try:
            # Generate HTML
            html = generate_html(ast)
            html_file = output_path / "index.html"
            html_file.write_text(html, encoding='utf-8')
            print_success(f"Generated {html_file}")

            # Generate CSS
            css = generate_css(ast)
            css_file = output_path / "style.css"
            css_file.write_text(css, encoding='utf-8')
            print_success(f"Generated {css_file}")

            # Generate JS
            js = generate_js(ast)
            js_file = output_path / "app.js"
            js_file.write_text(js, encoding='utf-8')
            print_success(f"Generated {js_file}")

            return True

        except Exception as e:
            print_error(f"Web compilation failed: {e}")
            return False

    def _compile_console(self, ast, output_path: Path) -> bool:
        """Compile to console application (Node.js or Python)"""
        try:
            # Generate JavaScript
            js = generate_js(ast)
            js_file = output_path / "main.js"
            js_file.write_text(js, encoding='utf-8')
            print_success(f"Generated {js_file}")

            return True

        except Exception as e:
            print_error(f"Console compilation failed: {e}")
            return False

    def _compile_llvm(self, ast, output_path: Path) -> bool:
        """Compile to LLVM IR"""
        try:
            # Generate LLVM IR
            llvm_ir = generate_llvm(ast)
            llvm_file = output_path / "main.ll"
            llvm_file.write_text(llvm_ir, encoding='utf-8')
            print_success(f"Generated {llvm_file}")

            return True

        except Exception as e:
            print_error(f"LLVM compilation failed: {e}")
            return False


class ProjectCreator:
    """Creates new Mr.X projects"""

    TEMPLATES = {
        "web": {
            "name": "Web Application",
            "description": "A modern web application with HTML, CSS, and JavaScript",
            "files": {
                "main.mrx": '''صفحة "My App"
عنوان "مرحبا بالعالم"

نص "هذا تطبيق Mr.X الأول"

زر "ابدأ"
''',
                "README.md": "# My Mr.X Web App\n\nBuild with: mrx build main.mrx\n"
            }
        },
        "api": {
            "name": "API Server",
            "description": "A REST API server using Mr.X",
            "files": {
                "server.mrx": '''
دالة handle_request(req):
    ارجع "مرحبا من API"

صفحة "API Server"
''',
                "README.md": "# My Mr.X API\n\nBuild with: mrx build server.mrx\n"
            }
        },
        "cli": {
            "name": "CLI Application",
            "description": "A command-line application",
            "files": {
                "main.mrx": '''
خلي name = "World"
قول "مرحبا " + name + "!"

كرر 3:
    قول "Mr.X رائع!"
''',
                "README.md": "# My Mr.X CLI App\n\nRun with: mrx run main.mrx\n"
            }
        },
        "blank": {
            "name": "Blank Project",
            "description": "An empty project to start from scratch",
            "files": {
                "main.mrx": "",
                "README.md": "# My Mr.X Project\n\nStart coding here!\n"
            }
        }
    }

    def create_project(self, name: str, template: str, path: str = ".") -> bool:
        """
        Create a new Mr.X project.

        Args:
            name: Project name
            template: Template to use ("web", "api", "cli", "blank")
            path: Directory to create project in

        Returns:
            True if project was created successfully
        """
        if template not in self.TEMPLATES:
            print_error(f"Unknown template: {template}")
            print_info(f"Available templates: {', '.join(self.TEMPLATES.keys())}")
            return False

        project_path = Path(path) / name

        if project_path.exists():
            print_error(f"Directory already exists: {project_path}")
            return False

        # Create project directory
        project_path.mkdir(parents=True)
        print_success(f"Created project: {name}")

        # Create files
        template_data = self.TEMPLATES[template]
        for filename, content in template_data["files"].items():
            filepath = project_path / filename
            filepath.write_text(content, encoding='utf-8')
            print_success(f"Created {filename}")

        # Create config
        config = {
            "name": name,
            "template": template,
            "version": "1.0.0",
            "mrx_version": "1.0.0"
        }
        config_file = project_path / "mrx.json"
        config_file.write_text(json.dumps(config, indent=2))
        print_success("Created mrx.json")

        print_header(f"Project '{name}' created successfully!")
        print_info(f"Location: {project_path}")
        print_info(f"Template: {template_data['name']}")
        print()
        print_info("Next steps:")
        print(f"  cd {name}")
        print(f"  mrx build main.mrx  # Build the project")
        print(f"  mrx run main.mrx     # Run the project")

        return True


class Runner:
    """Runs Mr.X programs"""

    def run_file(self, filepath: str, context: str = "console") -> bool:
        """
        Run a .mrx file.

        Args:
            filepath: Path to the source file
            context: Execution context

        Returns:
            True if execution succeeded
        """
        print_info(f"Running {filepath}...")

        try:
            # Parse the file
            parser = Parser()
            ast = parser.parse_file(filepath)

            # Execute
            runtime = execute(ast, context)

            if runtime.get_errors():
                for error in runtime.get_errors():
                    print_error(error)
                return False

            print_success("Execution completed")
            return True

        except Exception as e:
            print_error(f"Execution failed: {e}")
            return False

    def run_repl(self):
        """Run the Mr.X REPL"""
        print_header("Mr.X REPL")
        print_info("Type 'exit' or 'quit' to exit")
        print_info("Type 'help' for help")
        print()

        runtime = Runtime()
        parser = Parser()

        while True:
            try:
                code = input(color("mrx> ", Colors.CYAN))

                if code in ['exit', 'quit', 'خروج']:
                    print_info("Goodbye!")
                    break

                if code in ['help', 'مساعدة']:
                    print("Commands:")
                    print("  exit, quit - Exit the REPL")
                    print("  help - Show this help")
                    print()
                    continue

                if not code.strip():
                    continue

                # Parse and execute
                ast = parser.parse(code)
                runtime.execute(ast)

                # Print output
                for output in runtime.get_output():
                    print(output)

            except KeyboardInterrupt:
                print("\nUse 'exit' to quit")
            except Exception as e:
                print_error(f"Error: {e}")


class Server:
    """Development server for Mr.X web applications"""

    def __init__(self, port: int = 8000, host: str = "localhost"):
        self.port = port
        self.host = host

    def serve(self, directory: str = "output"):
        """Start the development server"""
        print_header("Mr.X Development Server")
        print_info(f"Serving: {directory}")
        print_info(f"URL: http://{self.host}:{self.port}")
        print_info("Press Ctrl+C to stop")
        print()

        # Check if directory exists
        dir_path = Path(directory)
        if not dir_path.exists():
            print_error(f"Directory not found: {directory}")
            print_info("Run 'mrx build' first to create the output")
            return

        # Start server
        import http.server
        import socketserver

        class Handler(http.server.SimpleHTTPRequestHandler):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, directory=directory, **kwargs)

        with socketserver.TCPServer((self.host, self.port), Handler) as httpd:
            print_success(f"Server running at http://{self.host}:{self.port}")
            try:
                httpd.serve_forever()
            except KeyboardInterrupt:
                print("\nServer stopped")


class MrXCLI:
    """Main CLI class"""

    VERSION = "1.0.0"

    def __init__(self):
        self.parser = argparse.ArgumentParser(
            prog="mrx",
            description="Mr.X - Arabic-first programming language",
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Examples:
  mrx new project_name          Create a new project
  mrx build app.mrx             Build a .mrx file
  mrx run app.mrx               Run a .mrx file
  mrx serve                     Start development server
  mrx version                   Show version information

For more information, visit: https://github.com/mrx-lang/mrx
            """
        )

        self._add_subcommands()

    def _add_subcommands(self):
        """Add subcommands to the parser"""
        subparsers = self.parser.add_subparsers(dest="command", help="Commands")

        # New project command
        new_parser = subparsers.add_parser("new", help="Create a new project")
        new_parser.add_argument("name", help="Project name")
        new_parser.add_argument("-t", "--template", default="web",
                               choices=["web", "api", "cli", "blank"],
                               help="Project template (default: web)")
        new_parser.add_argument("-p", "--path", default=".",
                               help="Directory to create project in")

        # Build command
        build_parser = subparsers.add_parser("build", help="Build a .mrx file")
        build_parser.add_argument("file", help="Source file to build")
        build_parser.add_argument("-o", "--output", default="output",
                               help="Output directory (default: output)")
        build_parser.add_argument("-t", "--target", default="web",
                               choices=["web", "console", "llvm"],
                               help="Build target (default: web)")

        # Run command
        run_parser = subparsers.add_parser("run", help="Run a .mrx file")
        run_parser.add_argument("file", help="Source file to run")

        # Serve command
        serve_parser = subparsers.add_parser("serve", help="Start development server")
        serve_parser.add_argument("-d", "--directory", default="output",
                                help="Directory to serve (default: output)")
        serve_parser.add_argument("-p", "--port", type=int, default=8000,
                                help="Port to listen on (default: 8000)")
        serve_parser.add_argument("--host", default="localhost",
                                help="Host to bind to (default: localhost)")

        # REPL command
        subparsers.add_parser("repl", help="Start Mr.X REPL")
        subparsers.add_parser("console", help="Start Mr.X console")

        # Version command
        subparsers.add_parser("version", help="Show version information")

        # Init command
        init_parser = subparsers.add_parser("init", help="Initialize a Mr.X project")
        init_parser.add_argument("-n", "--name", default="my-project",
                                help="Project name")

    def run(self, args: List[str] = None):
        """Run the CLI"""
        parsed = self.parser.parse_args(args)

        if not parsed.command:
            self.parser.print_help()
            return

        if parsed.command == "new":
            creator = ProjectCreator()
            creator.create_project(parsed.name, parsed.template, parsed.path)

        elif parsed.command == "build":
            compiler = Compiler()
            success = compiler.compile_file(
                parsed.file,
                parsed.output,
                parsed.target
            )
            sys.exit(0 if success else 1)

        elif parsed.command == "run":
            runner = Runner()
            success = runner.run_file(parsed.file)
            sys.exit(0 if success else 1)

        elif parsed.command == "serve":
            server = Server(port=parsed.port, host=parsed.host)
            server.serve(parsed.directory)

        elif parsed.command in ["repl", "console"]:
            runner = Runner()
            runner.run_repl()

        elif parsed.command == "version":
            print_header("Mr.X Programming Language")
            print(f"Version: {color(self.VERSION, Colors.GREEN)}")
            print(f"File extension: {color('.mrx', Colors.CYAN)}")
            print()
            print_info("Arabic-first. Modern. Powerful.")

        elif parsed.command == "init":
            creator = ProjectCreator()
            creator.create_project(parsed.name, "blank", ".")


def main():
    """Main entry point"""
    cli = MrXCLI()
    cli.run()


if __name__ == "__main__":
    main()