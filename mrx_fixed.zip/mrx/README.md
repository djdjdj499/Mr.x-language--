# Mr.X - لغة برمجة عربية أولاً

<div align="center">

**لغة برمجة عربية أولاً وإطار عمل لتطوير الويب**

[التثبيت](#التثبيت) • [البداية السريعة](#البداية-السريعة) • [الوثائق](#الوثائق) • [الأمثلة](#الأمثلة)

![Mr.X Logo](https://img.shields.io/badge/Mr.X-برمجة-عربية-4CAF50?style=for-the-badge&logo=python&logoColor=white)

</div>

---

## ✨ المميزات

- **بناء جملة عربي أولاً**: اكتب البرامج بالعربية مع دعم كامل لـ Unicode
- **دعم الإنجليزية**: استخدم الإنجليزية للمتغيرات وواجهات برمجة التطبيقات والمصطلحات التقنية
- **إطار عمل الويب**: أنشئ مواقع ويب حديثة كاملة من ملفات `.mrx`
- **بنية معيارية**: كود نظيف وقابل للتوسع للتوسع السهل
- **متعدد المنصات**: يعمل على Termux و Linux و Windows و Mac
- **مستعد للمستقبل**: مُعد للتجميع الأصلي باستخدام LLVM

---

## 📦 التثبيت

### Termux (Android)

```bash
pkg update && pkg upgrade
pkg install python git -y
pip install lark
git clone https://github.com/mrx-lang/mrx.git
cd mrx
python main.py --help
```

### Linux / macOS

```bash
# استنساخ المستودع
git clone https://github.com/mrx-lang/mrx.git
cd mrx

# تثبيت التبعيات
pip install lark

# تشغيل
python main.py --help
```

### Windows

```powershell
# باستخدام PowerShell
git clone https://github.com/mrx-lang/mrx.git
cd mrx
pip install lark
python main.py --help
```

---

## 🚀 البداية السريعة

### 1. إنشاء مشروع جديد

```bash
python main.py new my-project
cd my-project
```

### 2. اكتب برنامجك الأول

أنشئ ملف `main.mrx`:

```mrx
صفحة "موقعي الأول"

عنوان "مرحبا بالعالم"

نص "هذا موقعي الأول مع Mr.X"

زر "ابدأ الآن"
```

### 3. بناء الموقع

```bash
python main.py build main.mrx
```

### 4. عرض النتيجة

```bash
python main.py serve
# افتح http://localhost:8000
```

---

## 📖 دليل اللغة

### الكلمات المفتاحية الأساسية

| العربية | الإنجليزية | الوصف |
|---------|------------|-------|
| `قول` | print | طباعة إلى المخرجات |
| `خلي` | let | تعريف متغير |
| `لو` | if | عبارة شرطية |
| `غير_ذلك` | else | الفرع البديل |
| `كرر` | for | حلقة بعدد مرات |
| `دالة` | function | تعريف دالة |
| `ارجع` | return | العودة من الدالة |
| `استورد` | import | استيراد وحدة |

### المتغيرات

```mrx
خلي name = "أحمد"
خلي age = 25
خلي is_student = صحيح
```

### الشروط

```mrx
لو age > 18:
    قول "أنت بالغ"
غير_ذلك:
    قول "أنت طفل"
```

### الحلقات

```mrx
كرر 5:
    قول "مرحبا"

كرر 3:
    قول "iteration"
```

### الدوال

```mrx
دالة greet(name):
    قول "مرحبا " + name

دالة add(a, b):
    ارجع a + b
```

---

## 🌍 عناصر إطار عمل الويب

### هيكل الصفحة

```mrx
صفحة "موقعي"
عنوان "عنوان الصفحة"

# شريط التنقل
قائمة:
    رابط "/" "الرئيسية"
    رابط "/about" "من نحن"

# المحتوى
حاوية:
    قسم:
        عنوان "مرحبا"
        نص "مرحبا بكم في موقعنا"

# التخطيطات
شبكة 3:
    بطاقة: نص "بطاقة 1"
    بطاقة: نص "بطاقة 2"
    بطاقة: نص "بطاقة 3"

مرن:
    نص "مرن 1"
    نص "مرن 2"

# النماذج
نموذج:
    حقل "الاسم" "أدخل اسمك"
    حقل "البريد" "أدخل بريدك"
    زر "إرسال"

# التذييل
تذييل:
    نص "© 2024 موقعي"
```

### العناصر المتاحة

| العنصر | الوصف |
|--------|-------|
| `صفحة` | حاوية الصفحة |
| `عنوان` | عنوان (h1-h6) |
| `نص` | فقرة نصية |
| `زر` | زر |
| `صورة` | صورة |
| `حقل` | حقل إدخال |
| `قائمة` | شريط تنقل |
| `بطاقة` | مكون بطاقة |
| `قسم` | قسم |
| `نموذج` | نموذج |
| `تذييل` | تذييل |
| `رابط` | رابط تشعبي |
| `حاوية` | حاوية |
| `شبكة` | شبكة CSS |
| `مرن` | Flexbox |
| `فيديو` | عنصر فيديو |

---

## 🛠️ أوامر سطر الأوامر

### إدارة المشاريع

```bash
# إنشاء مشروع جديد
python main.py new project-name

# إنشاء من قالب
python main.py new project-name --template web
python main.py new project-name --template api
python main.py new project-name --template cli

# تهيئة المشروع
python main.py init
```

### البناء

```bash
# بناء تطبيق ويب
python main.py build main.mrx

# البناء مع مسار مخصص
python main.py build main.mrx --output dist

# البناء لهدف مختلف
python main.py build main.mrx --target console
python main.py build main.mrx --target llvm
```

### التشغيل

```bash
# تشغيل برنامج كونسول
python main.py run main.mrx

# بدء خادم التطوير
python main.py serve

# تشغيل على بورت مخصص
python main.py serve --port 3000

# تشغيل مجلد محدد
python main.py serve --directory dist
```

### التطوير

```bash
# بدء REPL
python main.py repl

# عرض الإصدار
python main.py version
```

---

## 📁 هيكل المشروع

```
mrx/
├── compiler/           # مكونات المصرف
│   ├── lexer.py        # المحلل اللغوي
│   ├── parser.py       # المحلل باستخدام Lark
│   ├── ast_nodes.py    # تعريفات عقد AST
│   ├── semantic.py     # المحلل الدلالي
│   └── codegen/        # مولدات الكود
│       ├── html_generator.py
│       ├── css_generator.py
│       ├── js_generator.py
│       └── llvm_generator.py
├── runtime/            # بيئة التشغيل
│   └── runtime.py
├── cli/                # واجهة سطر الأوامر
│   └── cli.py
├── examples/           # برامج أمثلة
│   ├── 01_hello.mrx
│   ├── 02_variables.mrx
│   └── ...
├── std/                # المكتبة القياسية
├── templates/          # قوالب المشاريع
├── output/             # مخرجات البناء
└── main.py             # نقطة الدخول
```

---

## 🔧 البنية التقنية

### مسار المصرف

```
كود المصدر (.mrx)
        ↓
    [المحلل اللغوي] → الرموز
        ↓
    [المحلل] → AST
        ↓
[المحلل الدلالي] → AST سليم
        ↓
    [مولدات الكود]
        ↓
    المخرجات
   (HTML/CSS/JS/LLVM)
```

### أنواع عقد AST

- **العبارات**: Print, Let, If, Loop, Function, Return, Class, Import
- **التعبيرات**: Identifier, Literals, Binary, Call, Member
- **عناصر الويب**: Page, Title, Text, Button, Image, Input, Nav, Card, etc.

### مولدات الكود

1. **مولد HTML**: ينشئ هيكل HTML من عناصر الويب
2. **مولد CSS**: ينشئ CSS متجاوب وعصري
3. **مولد JavaScript**: ينتج JavaScript قابل للتنفيذ
4. **مولد LLVM**: ينشئ LLVM IR (التجميع الأصلي المستقبلي)

---

## 🧪 الأمثلة

### مرحبا بالعالم

```mrx
قول "مرحبا بالعالم!"
```

### المتغيرات والشروط

```mrx
خلي name = "Mohsen"

لو name == "Mohsen":
    قول "owner"
غير_ذلك:
    قول "guest"
```

### موقع مقهى

```mrx
صفحة "Coffee"

عنوان "أفضل قهوة"

نص "مرحبا بكم"

زر "اطلب الآن"

بطاقة:
    عنوان "قهوة عربية"
    نص "مذاق رائع"
```

---

## 🔮 خارطة طريق المستقبل

- [ ] **مولد تطبيقات الجوال**: بناء تطبيقات iOS/Android
- [ ] **التجميع الأصلي**: خلفية LLVM للثنائيات الأصلية
- [ ] **تكامل الذكاء الاصطناعي**: أدوات ذكاء اصطناعي مدمجة
- [ ] **مدير الحزم**: تثبيت ونشر حزم Mr.X
- [ ] **إطار عمل سطح المكتب**: بناء تطبيقات سطح المكتب
- [ ] **إطار عمل APIs**: إنشاء واجهات برمجة التطبيقات
- [ ] **ORM لقواعد البيانات**: دعم قواعد البيانات المدمج

---

## 📝 التطوير

### المتطلبات

- Python 3.8+
- Lark parser

### الإعداد

```bash
git clone https://github.com/mrx-lang/mrx.git
cd mrx
pip install -r requirements.txt
```

### تشغيل الاختبارات

```bash
# اختبار المصرف اللغوي
python -m compiler.lexer

# اختبار المحلل
python -m compiler.parser

# اختبار البناء
python main.py build examples/01_hello.mrx
```

---

## 🤝 المساهمة

1. Fork المستودع
2. أنشئ فرع للميزة
3. قدم تغييراتك
4. شغّل الاختبارات
5. أرسل طلب سحب

---

## 📄 الترخيص

MIT License - راجع ملف LICENSE للتفاصيل.

---

## 🌍 الموارد

- **الوثائق**: [docs.mrx-lang.dev](https://docs.mrx-lang.dev)
- **GitHub**: [github.com/mrx-lang/mrx](https://github.com/mrx-lang/mrx)
- **Discord**: [انضم لمجتمعنا](https://discord.gg/mrx-lang)

---

<div align="center">

**صُنع بـ ❤️ للمجتمع البرمجي العربي**

</div>