#!/usr/bin/env python3
"""
Mr.X Programming Language - Main Entry Point

Mr.X is an Arabic-first programming language designed to make
programming accessible to Arabic speakers while maintaining
full English support for technical terms.

Author: Mr.X Team
Version: 1.0.0
"""

import sys
import os
from pathlib import Path

# Add project root to Python path
PROJECT_ROOT = Path(__file__).parent
sys.path.insert(0, str(PROJECT_ROOT))

from cli.cli import MrXCLI


def main():
    """Main entry point for Mr.X language"""
    cli = MrXCLI()
    cli.run()


if __name__ == "__main__":
    main()